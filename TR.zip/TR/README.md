# FSI
This is the Matlab code of FSI from the paper "Reduced-reference image quality assessment in free-energy principle and sparse representation", IEEE Transactions on Multimedia, 2018.

Usage:
(1) change the file directory to "xxx\FSI_pub\FSI_pub\gbvs\gbvs" and enter the commond "gbvs_install"
(2) change the file directory to "xxx\FSI_pub\FSI_pub\" and run demo.m

Thanks for testing.
