path = genpath('D:\saliency');
addpath(path);

dis = 'D:\imageDatabase\live\gblur\';
ref = 'D:\imageDatabase\live\refimgs\';
load 'D:\imageDatabase\live\live_dmos\gb_dmos.mat';
load 'D:\imageDatabase\live\live_ref\gb_ref.mat';
iter = sum(gb_dmos~=0);
ind = find(gb_dmos~=0);
fedm = zeros(1000,1);
nfqm = zeros(1000,1);
for i = 1:iter
i
dis_path = [dis,'img',num2str(ind(i)),'.bmp'];
ref_path = [ref,gb_ref{ind(i)}];

dis_img = imread(dis_path);
ref_img = imread(ref_path);

ref_sal = gbvs(ref_img);
dis_sal = gbvs(dis_img);

ref_sal = ref_sal.master_map_resized;
dis_sal = dis_sal.master_map_resized;

[ref_es,ref_err,ref_rec] = FEDM_ref(rgb2gray(ref_img),ref_sal);
[dis_es,dis_err,dis_rec] = FEDM_dis(rgb2gray(dis_img),dis_sal);

% rec_path = ['D:\refimgs\ar_rec\',num2str(i),'.bmp'];
% imwrite(uint8(rec),rec_path);
fedm(i) = abs(dis_es-ref_es);
nfqm(i) = dis_es;
end

fedm = fedm(1:iter);
nfqm = nfqm(1:iter);
save('D:\imageDatabase\live\sal_s_dct_64_128_gb_fedm.mat','fedm');
save('D:\imageDatabase\live\sal_s_dct_64_128_gb_nfqm.mat','nfqm');

gb_dmos = gb_dmos(ind);
fedm_srocc = corr(gb_dmos',fedm,'type','spearman')
% corr(gb_dmos',fedm,'type','pearson')
nfqm_srocc = corr(gb_dmos',nfqm,'type','spearman')
% corr(gb_dmos',nfqm,'type','pearson')