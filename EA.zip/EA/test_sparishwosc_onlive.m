%test the effectiveness of sparish on live
load Dic.mat;  %load the LiLeida training dictionary;
% obtain DCT dictionary from Liu
k=1;
for i=1:174
   if ~orgs(i+634)
       gb_mos(k)=SPARISH_without_sparsecoding(rgb2gray(Gb_dst{i}));
       gb_dmos(k)=dmos_new(i+634);
       k=k+1;
   end
end
srocc=corr(gb_mos',gb_dmos','type','Spearman')