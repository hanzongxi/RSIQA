function [Es err imgrec]=fsi(imgin)
% clc;
% imgin=imread('lena.pgm');
% imgin=imgin(201:300,201:300);

%imgin=double(rgb2gray(imgin));
imgin=double(imgin);
imgrec = sparse_reconstruct(imgin);
err=imgin-imgrec;
xx=-255:255;
y=round(err);
[nn xout]=hist(y(:),xx);
p=(1+2*nn)/sum(1+2*nn);
Es = -sum(p.*log2(p));
 