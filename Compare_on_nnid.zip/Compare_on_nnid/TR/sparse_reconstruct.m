% reconstruct image with k-svd
function YY = sparse_reconstruct(I)

    block_size=8;
    bb = 8;
    Y1 = double(I);
    [NN1,NN2] = size(Y1);
    K = 128;
    Pn=ceil(sqrt(K));
    DCT=zeros(bb,Pn);

    for k=0:1:Pn-1,
        V=cos([0:1:bb-1]'*k*pi/Pn);
        if k>0, V=V-mean(V); end;
        DCT(:,k+1)=V/norm(V);
    end;
    DCT=kron(DCT,DCT);
    [blocks,idx] = my_im2col(Y1,[block_size,block_size],8);
   
    L = 6;
    for jj = 1:30000:size(blocks,2)
        jumpSize = min(jj+30000-1,size(blocks,2));
        %Coefs = mexOMPerrIterative(blocks(:,jj:jumpSize),Dictionary,errT);
        Coefs = OMP(DCT,blocks(:,jj:jumpSize),L);
        Recon_blocks(:,jj:jumpSize)= DCT*Coefs;

    end

    count = 1;
    Weight = zeros(NN1,NN2);
    IMout = zeros(NN1,NN2);
    [rows,cols] = ind2sub(size(Y1)-bb+1,idx);
    for i  = 1:length(cols)
        col = cols(i); row = rows(i);
        block =reshape(Recon_blocks(:,count),[bb,bb]);
        IMout(row:row+bb-1,col:col+bb-1)=IMout(row:row+bb-1,col:col+bb-1)+block;
        Weight(row:row+bb-1,col:col+bb-1)=Weight(row:row+bb-1,col:col+bb-1)+ones(bb);
        count = count+1;
    end;

    YY = IMout./Weight;
end