ref_img = imread('I01.bmp');
dis_img = imread('I01_01_1.bmp');

ref_img = rgb2gray(ref_img);
dis_img = rgb2gray(dis_img);

ref_f = fsi(ref_img);
dis_f = fsi(dis_img);

score = abs(ref_f-dis_f)