dis = 'D:\imageDatabase\live\gblur\';
for i = 1:145
img_path = [dis,'img',num2str(i),'.bmp'];
I = imread(img_path);

[es,err] = FEDM(rgb2gray(I));
% rec_path = ['D:\refimgs\ar_rec\',num2str(i),'.bmp'];
% imwrite(uint8(rec),rec_path);
entropy(i)=es;
end
save('D:\D:\imageDatabase\live\sparse_gb_entropy.mat','entropy');