
function [noiseSD,kurt] = fitShapeAndSDUsingKurts(noiseVars,noiseKurts)
   [x,fval,exitflag] = fminsearch(@(x) myminfun(x,noiseVars,noiseKurts),[min(noiseKurts(2:end)) min(noiseVars(2:end)).^0.5],optimset('MaxFunEvals',100000,'MaxIter',100000));
   %[x,fval,exitflag] = fminsearch(@(x) myminfun(x,noiseVars,noiseKurts),[min(noiseKurts(2:end)) 0.5],optimset('MaxFunEvals',100000,'MaxIter',100000));
   %[x val]= fminsearch(@(x) versuch_optim_2(x,temp,t,y1,f,g,ft,gt), [1,1],optimset('MaxFunEvals',10000,'MaxIter',10000))
   
   noiseSD = x(2);
   kurt = x(1);
   if exitflag==0
       noiseSD = NaN;
       kurt = NaN;
   end
end

function F = myminfun(guesses,noiseVars,noiseKurts)
    N = length(noiseVars);
    kurt = guesses(1);
    sd = guesses(2);
    F = 0;
    for i=2:N
        F = F + (kurtFunc(kurt,sd,i,noiseVars) - noiseKurts(i)).^2;
    end
    %F
end