% clear
% clc
load ./NNID/2048name.mat
feat = [];
for i = 1:450
    i
    img_path = ['./NNID/Sub2048/',name2048{i}];
    img = imread(img_path);
    feat(i,:) = riqa_feature(img); % or bniqm_feature(img)
    
end

save riqa_feat_2048.mat feat;