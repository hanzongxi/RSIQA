function [W,omega] = DCTBasis(patchSize)
% create a patchSize x patchSize DCT filter matrix
% rows of W are the filters

N = patchSize;
W = zeros(N^2,N^2);
k=1;
omega = zeros(N*N,1);
for p=0:N-1
    for q=0:N-1
        if p==0
            ap = 1/sqrt(N);
        else
            ap = sqrt(2/N);
        end
        if q==0
            aq = 1/sqrt(N);
        else
            aq = sqrt(2/N);
        end

        % generate the (p,q) filter
        w = zeros(N,N);    
        for m=0:N-1
            for n=0:N-1
                w(m+1,n+1) = ap*aq*cos(pi*(2*m+1)*p/(2*N))*cos(pi*(2*n+1)*q/(2*N));
            end
        end
        
        W(k,:) = reshape(w,1,N*N);
        omega(k) = sqrt(p*p+q*q);
        k=k+1;
    end
end
% sort by total spatial frequency
[omega,I] = sort(omega,'ascend');
W = W(I,:);
