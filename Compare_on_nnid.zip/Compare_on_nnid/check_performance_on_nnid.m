load ./2048mos.mat;
load riqa_feat_2048.mat; % Or load bniqm_feat_2048 to compare performances of different feature sets. 
%load bniqm_feat_2048.mat; 

inst=feat; 
label=mos2048;


ssrcc = [];
skrcc = [];
splcc = [];
srmse = [];


test_train_ratio = 0.8;

g = 2^-6;
c = 2^7;
parameter = ['-s' ' 3 ' '-t' ' 2 ' '-g' ' ' num2str(g) ' ' '-c' ' ' num2str(c) ' -q' ];
%
for k = 1:10
    k
    idx = randperm(450);   
    train_idx = idx(1:floor(450*test_train_ratio));
    test_idx = idx(ceil(450*test_train_ratio):450);   
    train_label = label(train_idx);
    train_inst = inst(train_idx,:);
    test_label = label(test_idx);
    test_inst = inst(test_idx,:);
    
    %% You could experiment with the three regressors as descirbed in the paper.
    %% Random forest
    % Mdl=TreeBagger(100,train_inst,train_label,Method="regression");  
    % predict_label = predict(Mdl, test_inst);
    
    %% Feature Normalization
    % [inst_normal, PS]=mapminmax(inst',0,1);
    % inst=inst_normal';
    % save normalization.mat PS; 
    
    %% SVR
    svmmodel = svmtrain(train_label,train_inst,parameter);
    ttest_label = zeros(size(test_label));
    [predict_label, accuracy, dec_values]  = svmpredict(ttest_label, test_inst, svmmodel); 
     
    [ss,kk,pp,rr] = verify_performance(test_label,predict_label);
    ssrcc(k) = abs(ss);
    skrcc(k) = abs(kk);
    splcc(k) = abs(pp);
    srmse(k) = abs(rr);
end
%---------------------------------------------------------------------------------%
%---------------------------------------------------------------------------------%

mean(ssrcc)   
mean(skrcc)   
mean(splcc)   
mean(srmse)   