clear all;
clc;

tic

load Dic.mat; 
img = imread('rapids.bmp');
score = SPARISH(img,Dic)

toc

