%================================================================
% image blocks 8*8
%================================================================

function [signal_block,var_block]=blocks(image)

[m n z] = size(image);
if z > 1
    image = rgb2gray(image);
end
image=double(image);
rb = 8;
cb = 8;

% maximum block indices 
r = floor(m/rb);
c = floor(n/cb);

signal_block=zeros(rb*cb,r*c);
var_block=zeros(1,r*c);

k=0;
for i=1:r
    for j=1:c
        k=k+1;
        row = (rb*(i-1)+1):rb*i;
        col = (cb*(j-1)+1):cb*j;
        image_temp = image(row,col);

        [Gx Gy] = gradient(image_temp);
         graI = abs(Gx) + abs(Gy);  % Magnitude
        
         signal_block(:,k)=graI(:);
         var_block(:,k)=var2(image_temp);      
    end
end