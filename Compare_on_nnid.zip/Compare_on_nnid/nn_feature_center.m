function feat = nn_feature_center(I)

% load('squeeze_feat_2048.mat')
% I=imread('D1_IC01_img1.jpg');
% b=I(910:1136,910:1136,:);
% feat1=nn_feature(b);

[M,N,~]=size(I);
left1=floor((M-227)/2);
left2=floor((N-227)/2);
b=I(left1:left1+227,left2:left2+227,:);
feat=nn_feature(b);
feat=feat';