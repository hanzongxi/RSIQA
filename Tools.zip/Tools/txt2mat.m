file = fopen('predict_mos_stairiqa.txt','r');
dataArray = textscan(file, '%f');
predict_mos_stairiqa=dataArray{1,1};

save predict_mos_stairiqa.mat predict_mos_stairiqa