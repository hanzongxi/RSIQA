addpath './natsortfiles'
imgDataPath='./';
imgDataDir=dir(imgDataPath);%遍历所有文件
naming={};
for i=1:length(imgDataDir)
if (isequal(imgDataDir(i).name,'.')|| isequal(imgDataDir(i).name,'..')||~imgDataDir(i).isdir)%去除遍历中不是文件夹的
continue;
end

imgDir=dir([imgDataPath imgDataDir(i).name '/*.jpg']);

for j=1:length(imgDir)%遍历所有图片

%img=imread([imgDataPath imgDataDir(i).name '/' imgDir(j).name]);
naming=[naming [imgDataPath imgDataDir(i).name '/' imgDir(j).name]];
names=natsort(naming);
save names.mat names

end

end