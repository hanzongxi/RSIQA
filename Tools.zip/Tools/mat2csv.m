load('names.mat');

a=table(names','VariableNames',"names");
write(a,'names.csv')
