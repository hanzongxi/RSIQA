[num, txt, raw] = xlsread('MOS_distribution');
num1 = num(1:31,2:18);
mos = num1(~isnan(num1));
save mos.mat mos;