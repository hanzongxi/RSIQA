function output=multi_fusion(input)

%% This is deciphered version of the multi_fusion.p file
   img=double(input);
   HSV=rgb2hsv(img);

   H=HSV(:,:,1);
   S=HSV(:,:,2);

%% The square structuring element is different from the disk shape described in the paper. The closing operation
%% will eliminate very fine_grained and darker details, making the output result a little brighter and smooother.
%% Moreover,this version provided by the author didn't use the guided filter described in the paper.
   L=max(img,[],3);
   % figure,imshow(uint8(L));
   struct=strel('square',5);
   L=imclose(L,struct);
   % figure,imshow(uint8(L));
   
   % V=HSV(:,:,3);
   % L = imguidedfilter(L,V);
   % figure,imshow(uint8(L));
%%  Compute the Reflectance componet.The denominator compares the element in L with the number 1, avoiding the problem of division by zero.  
    R(:,:,1)=(img(:,:,1)./max(L,1));
    R(:,:,2)=(img(:,:,2)./max(L,1));
    R(:,:,3)=(img(:,:,3)./max(L,1));

%%  a=8+(1-ttt)/ttt; this number 8 is also slightly different from what the paper described: 10!    
    Y0=L./255;
    ttt=mean(Y0(:));
    a=8+(1-ttt)/ttt;
    Y1=(2*atan(a*(Y0))/pi);
    Y2=adapthisteq(Y0);

%% The following figure code reproduces the Fig.3 exactly
    baoguang0=exp(-((Y0-0.5).^2)/0.25);
    baoguang1=exp(-((Y1-0.5).^2)/0.25);
    baoguang2=exp(-((Y2-0.5).^2)/0.25);

    % figure,imshow(baoguang0);
    % figure,imshow(baoguang1);
    % figure,imshow(baoguang2);
    %% This formula is right for the reproduction of the Fig.3
    duibidu0=(Y0).*(1+0.7*cos(2*H+25*pi/36).*S);
    duibidu1=(Y1).*(1+0.7*cos(2*H+25*pi/36).*S);
    duibidu2=(Y2).*(1+0.7*cos(2*H+25*pi/36).*S);

    % figure,imshow(duibidu0);
    % figure,imshow(duibidu1);
    % figure,imshow(duibidu2);

    W0=baoguang0.*duibidu0;
    W1=baoguang1.*duibidu1;
    W2=baoguang2.*duibidu2;


    W00=W0./(W0+W1+W2+0.0001);
    W11=W1./(W0+W1+W2+0.0001);
    W22=W2./(W0+W1+W2+0.0001);

    % figure,imshow(W00,[]); colormap jet;
    % figure,imshow(W11,[]); colormap jet;
    % figure,imshow(W22,[]); colormap jet;

    W(:,:,1)=W00;W(:,:,2)=W11;W(:,:,3)=W22;
    I(:,:,1)=Y0;I(:,:,2)=Y1;I(:,:,3)=Y2;
%%  This is meant to reproduce the result in Fig.8, but we cann't reproduce it. It seems that only over-sharpening effect happens.
    % Lfinal_1=sum(W.*I,3);
    % L12_1=max(255*Lfinal_1,0);
    % figure,imshow(uint8(L12_1))
    % output_1(:,:,1)=R(:,:,1).*L12_1;
    % output_1(:,:,2)=R(:,:,2).*L12_1;
    % output_1(:,:,3)=R(:,:,3).*L12_1;
    % output_1=uint8(output_1);
    % figure,imshow(output_1)
    r=size(W00,1);
    c=size(W00,2);
    pyr=gaussian_pyramid(zeros(r,c,1));

    nlev=length(pyr);
    for i=1:3
        pyrW=gaussian_pyramid(W(:,:,i));
        pyrI=laplacian_pyramid(I(:,:,i));
        for l=1:nlev
            w=repmat(pyrW{l},[1,1,1]);
            pyr{l}=pyr{l}+w.*pyrI{l};
        end
    end

    Lfinal=reconstruct_laplacian_pyramid(pyr);
    L12=max(255*Lfinal,0);

    output(:,:,1)=R(:,:,1).*L12;
    output(:,:,2)=R(:,:,2).*L12;
    output(:,:,3)=R(:,:,3).*L12;
    output=uint8(output);
end


function R=downsample(I,filter)

    border_mode='symmetric';
    R=imfilter(I,filter,border_mode);
    R=imfilter(R,filter',border_mode);
    r=size(I,1);
    c=size(I,2);
    R=R(1:2:r,1:2:c,:);
end

function pyr=gaussian_pyramid(I,nlev)

    r=size(I,1);
    c=size(I,2);
    if~exist('nlev')
        nlev=floor(log(min(r,c))/log(2));
    end
    pyr=cell(nlev,1);
    pyr{1}=I;
    filter=pyramid_filter;
    for l=2:nlev
        I=downsample(I,filter);
        pyr{l}=I;
    end
end

function pyr=laplacian_pyramid(I,nlev)

    r=size(I,1);
    c=size(I,2);
    if~exist('nlev')
        nlev=floor(log(min(r,c))/log(2));
    end
    pyr=cell(nlev,1);
    filter=pyramid_filter;
    J=I;
    for l=1:nlev-1
        I=downsample(J,filter);
        odd=2*size(I)-size(J);
        pyr{l}=J-upsample(I,odd,filter);
        J=I;
    end
    pyr{nlev}=J;
end


function f=pyramid_filter
    f=[.0625,.25,.375,.25,.0625];
end


function R=reconstruct_laplacian_pyramid(pyr)

    r=size(pyr{1},1);
    c=size(pyr{1},2);
    nlev=length(pyr);

    R=pyr{nlev};
    filter=pyramid_filter;
    for l=nlev-1:-1:1
        odd=2*size(R)-size(pyr{l});
        R=pyr{l}+upsample(R,odd,filter);
    end
end



function R=upsample(I,odd,filter)

    I=padarray(I,[1,1,0],'replicate');
    r=2*size(I,1);
    c=2*size(I,2);
    k=size(I,3);
    R=zeros(r,c,k);
    R(1:2:r,1:2:c,:)=4*I;
    R=imfilter(R,filter);
    R=imfilter(R,filter');
    R=R(3:r-2-odd(1),3:c-2-odd(2),:);
end