function [R, I, error_R, error_I] = processing(S, c_1, c_2, miu, error)

beta = c_1;
alpha = c_2;
s = log(S+0.001);

I = ones(size(S));
R = ones(size(S));
i = ones(size(S));
r = ones(size(S));
r1 = ones(size(S));
i1 = ones(size(S));
b_y = zeros(size(S)); 
b_x = zeros(size(S));
eigsDtD = getC(S);
error_R = 10; error_I = 10;
display(['Relative errors:   epsilon_R = ', num2str(error_R), ',    epsilon_L = ', num2str(error_I)]);

while error_R>error || error_I>error
    if error_R > error
        h = [diff(r1, 1, 2), r1(:, 1, :) - r1(:, end, :)];
        v = [diff(r1, 1, 1); r1(1, :, :) - r1(end, :, :)];
        V1 = R .* h + b_y;
        V2 = R .* v + b_x;
        d_y = max(abs(V1) - 1 / (2 * miu), 0) .* sign(V1);
        d_x = max(abs(V2) - 1 / (2 * miu), 0) .* sign(V2);
        Denormin = 1 + beta * miu * R .* eigsDtD;
        tmpd_y = d_y - b_y;
        tmpd_x = d_x - b_x;
        Normin2 = [tmpd_y(:,end,:)-tmpd_y(:,1,:), -diff(tmpd_y, 1, 2)];
        Normin2 = Normin2 + [tmpd_x(end,:,:)-tmpd_x(1,:,:); -diff(tmpd_x,1,1)];
        FS = (fft2(s-i)+beta*miu*fft2(Normin2))./Denormin;
        r = real(ifft2(FS));
        r = min(0,r);
        b_y = b_y - (d_y-R.*[diff(r,1,2), r(:,1,:) - r(:,end,:)]);
        b_x = b_x - (d_x-R.*[diff(r,1,1); r(1,:,:) - r(end,:,:)]);
        error_R = norm((r-r1),2)/norm(r1,2);
        r1 = r;
        R = exp(r);
    end
    if error_I > error
        temp = fft2(s-r);
        i = ifft2(temp./(1+alpha.*I.*eigsDtD));
        i = real(i);
        i = max(i, s);
        error_I = norm((i-i1),2)/norm(i1,2);
        i1 = i;
        I = exp(i);
    end
    display(['Relative errors:   epsilon_R = ', num2str(error_R), ',    epsilon_L = ', num2str(error_I)]);
end
end

function eigsDtD = getC(F)
    fx = [1, - 1];
    fy = [1; - 1];
    [N, M, D] = size(F);
    sizeI2D = [N, M];
    otfFx = psf2otf(fx, sizeI2D);
    otfFy = psf2otf(fy, sizeI2D);
    eigsDtD = abs(otfFx).^2 + abs(otfFy).^2;
end
