%%%%%%% input:   image, parameters
%%%%%%% output:  estimated illumination: L, estimated reflectance: R, 
%%%%%%%          relative errors: epsilon_R, epsilon_L

%clc;clear all;
img=double(imread('ss.jpg'));%img = double(imresize(imread('N9_2.jpg'),0.25)); 
Reflectance=zeros(size(img));
Illuminance=zeros(size(img));
%% Converting to the HSV color space.
if size(img,3)>1
    HSV = rgb2hsv(img);   % RGB space to HSV  space
    S = HSV(:,:,3);       % V layer
else
    S = img;              % gray image
end
%% Setting parameters
c_1 = 0.01; c_2 = 0.1; lambda = 1;     
epsilon_stop = 1e-3;  % stopping criteria
%% Operating in the HSV color space.
[R, L, epsilon_R, epsilon_L] = processing222(S, c_1, c_2, lambda, epsilon_stop);
%% Operating in the RGB color space.
% for i=1:3
%   S=img(:,:,i);
%   [R, L, epsilon_R, epsilon_L] = processing111(S, c_1, c_2, lambda, epsilon_stop );
%   Reflectance(:,:,i)=R;
%   Illuminance(:,:,i)=L;
% end
% figure,imshow(Reflectance);
% figure,imshow(uint8(Illuminance));

%% Gamma correction
gamma = 2.2;
L_gamma = 255 * ((L/255).^(1/gamma));
enhanced_V = R .* L_gamma;
HSV(:,:,3) = enhanced_V;
enhanced_result = hsv2rgb(HSV);  

figure,imshow(uint8(enhanced_result));
% subplot(2,2,1),imshow(uint8(img)), title('input image');
% subplot(2,2,2),imshow(uint8(enhanced_result)),title('Gamma correction');
% subplot(2,2,3),imshow(uint8(L)), title('estimated illumination');
% subplot(2,2,4),imshow(R), title('estimated reflectance');




