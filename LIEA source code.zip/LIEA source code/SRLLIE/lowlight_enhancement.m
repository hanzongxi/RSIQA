function[R,L,E]=lowlight_enhancement(im,para)

    ro=para.ro;
    u=para.u;
    alpha=0;   % alpha is introduced in the IFTC2017 best paper, however, it is excluded from the TIP2018 paper, so alpha=0
    beta=para.beta;
    omega=para.omega;
    delta=para.delta;
    lambda=para.lambda;
    lambda1=0;
    lambda2=0;
    epsilon=para.epsilon;
    maxIter=30;
    im=im/255;
 % S1,S2,S3 serves as another substitute for im   
    S1=im(:,:,1);
    S2=im(:,:,2);
    S3=im(:,:,3);
 % Use the RGB2GRAY value as the initial L
    L1=im(:,:,1)*0.299+im(:,:,2)*0.587+im(:,:,3)*0.114;
    L2=L1;
    L3=L1;
%% This initialization of Nabla is correct and impressive, but very complex!
    [t1,t2,~]=size(im);

    indneg1=1:t1*t2;
    indneg1(mod(indneg1,t1)==1)=[];

    indneg2=1:t1*t2;    
    indneg2(mod(indneg2,t1)==0)=[];
    
    indpos1=indneg1;
    indpos2=indpos1;  
    
    indneg1=[indneg1,t1*t2+1:t1*t2+(t2-1)*t1];
    indneg2=[indneg2,1:(t2-1)*t1];
   
    indpos1=[indpos1,t1*t2+1:t1*t2+(t2-1)*t1];
    indpos2=[indpos2,t1+1:t1*t2];

    Nablaneg=sparse(indneg1,indneg2,-1,t1*t2+(t2-1)*t1,t1*t2);
    Nablapos=sparse(indpos1,indpos2,1,t1*t2+(t2-1)*t1,t1*t2);
    Nabla=Nablaneg+Nablapos;

    zz2=zeros(t1,t1*t2);
    Nabla=[Nabla(1:t1*t2,:);zz2;Nabla(t1*t2+1:end,:)];

%% W1, W2, W3 computes the G Matrix first      
    W1=Nabla*S1(:);

    tt1=W1(1:t1*t2);
    tt1=reshape(tt1,t1,t2);

    tt2=W1(1+t1*t2:end);
    tt2=reshape(tt2,t1,t2);
    W1=[tt1;tt2];
    %figure,imshow(W1,[]),save W1.mat W1

    W2=Nabla*S2(:);
    tt1=W2(1:t1*t2);
    tt1=reshape(tt1,t1,t2);
    tt2=W2(1+t1*t2:end);
    tt2=reshape(tt2,t1,t2);
    W2=[tt1;tt2];

    W3=Nabla*S3(:);
    tt1=W3(1:t1*t2);
    tt1=reshape(tt1,t1,t2);
    tt2=W3(1+t1*t2:end);
    tt2=reshape(tt2,t1,t2);
    W3=[tt1;tt2];
    %deltaX=diff(img,1,1), W1,W2,W3 are just first order derivative, why so complex?

% Then adjust the weight map according to the Equation(9), which helps to suppress noises mainly.
    W1(abs(W1)<epsilon)=0;
    W2(abs(W2)<epsilon)=0;
    W3(abs(W3)<epsilon)=0;
%% This is the Equation(7). If removing this three equations, the enhanced image will be low contrast, see the Fig.2.
    W1=(1+lambda*exp(-abs(W1)/10)).*W1;
    W2=(1+lambda*exp(-abs(W2)/10)).*W2;
    W3=(1+lambda*exp(-abs(W3)/10)).*W3;

 % Initialization 
    R=zeros(size(im));
    L=zeros(size(im));
    E=zeros(size(im));
    E1=E(:,:,1);
    E2=E(:,:,2);
    E3=E(:,:,3);    

    Z1=zeros(2*t1,t2);
    Z2=zeros(2*t1,t2);
    Z3=zeros(2*t1,t2);

    D1=zeros(2*t1,t2);
    D2=zeros(2*t1,t2);
    D3=zeros(2*t1,t2);
% R_pre and L_pre are initialized as the im(itself), so the first iteration error of R_pre will be large!
    R_pre=im;
    L_pre=im;
    DTD=Nabla'*Nabla;

%% Iteration begins
for iter=1:maxIter
%% Updating the reflectance, according to the Equation(14) in the paper.
        tW1=W1(1:t1,:);
        tW2=W1(1+t1:end,:);
        DTW=reshape(Nabla'*[tW1(:);tW2(:)],t1,t2);
        diagL=sparse(1:t1*t2,1:t1*t2,L1(:),t1*t2,t1*t2);
        % This is the Equation(14) provided in the paper.
        tt=2*reshape(diagL*(S1(:)-E1(:)),t1,t2)+2*omega*DTW;
        %% the 2*apha*DTD is the alpha*｜R|^2 norm in the IFTC2017 paper.
        ttt=2*diagL.*diagL+2*alpha*DTD+2*omega*DTD+sparse(1:t1*t2,1:t1*t2,lambda1,t1*t2,t1*t2);
        R1=ttt\tt(:);  % R1= inv(ttt)*tt(:)
        R1=reshape(R1,t1,t2);
        R1=max(0,R1);

% RGB三个通道再次重复上面R1的操作;           
        tW1=W2(1:t1,:);
        tW2=W2(1+t1:end,:);
        DTW=reshape(Nabla'*[tW1(:);tW2(:)],t1,t2);
        diagL=sparse(1:t1*t2,1:t1*t2,L2(:),t1*t2,t1*t2);
        tt=2*reshape(diagL*(S2(:)-E2(:)),t1,t2)+2*omega*DTW;
        ttt=2*diagL.*diagL+2*alpha*DTD+2*omega*DTD+sparse(1:t1*t2,1:t1*t2,lambda1,t1*t2,t1*t2);
        R2=ttt\tt(:);
        R2=reshape(R2,t1,t2);
        R2=max(0,R2);

        tW1=W3(1:t1,:);
        tW2=W3(1+t1:end,:);
        DTW=reshape(Nabla'*[tW1(:);tW2(:)],t1,t2);
        diagL=sparse(1:t1*t2,1:t1*t2,L3(:),t1*t2,t1*t2);
        tt=2*reshape(diagL*(S3(:)-E3(:)),t1,t2)+2*omega*DTW;
        ttt=2*diagL.*diagL+2*alpha*DTD+2*omega*DTD+sparse(1:t1*t2,1:t1*t2,lambda1,t1*t2,t1*t2);
        R3=ttt\tt(:);
        R3=reshape(R3,t1,t2);
        R3=max(0,R3);

%% Updating the illumination, according to the Equation(16) in the paper.
        tZ1=Z1(1:t1,:);
        tZ2=Z1(1+t1:end,:);
        DTZ1=reshape(Nabla'*[tZ1(:);tZ2(:)],t1,t2);
        tG1=D1(1:t1,:);
        tG2=D1(1+t1:end,:);
        DTD1=reshape(Nabla'*[tG1(:);tG2(:)],t1,t2);
        diagR=sparse(1:t1*t2,1:t1*t2,R1(:),t1*t2,t1*t2);
        %% DTZ1是Equation(16)的最后一项D^T*z(k)；DTD1是D^T*t(k),D1就是shrinkage后的t(k)，参见下面的Line202-211
        tt=2*reshape(diagR*(S1(:)-E1(:)),t1,t2)-DTZ1+u*DTD1; 
        %% sparse(1:t1*t2,1:t1*t2,lambda2,t1*t2,t1*t2)是全零稀疏矩阵
        ttt=2*diagR.*diagR+u*DTD+sparse(1:t1*t2,1:t1*t2,lambda2,t1*t2,t1*t2);

        L1=ttt\tt(:); % inv(ttt)*tt(:)
        L1=reshape(L1,t1,t2);
        L1=max(0,L1);

% RGB三个通道再次重复上面L1的操作;       
        tZ1=Z2(1:t1,:);
        tZ2=Z2(1+t1:end,:);
        DTZ1=reshape(Nabla'*[tZ1(:);tZ2(:)],t1,t2);
        tG1=D2(1:t1,:);
        tG2=D2(1+t1:end,:);
        DTD1=reshape(Nabla'*[tG1(:);tG2(:)],t1,t2);
        diagR=sparse(1:t1*t2,1:t1*t2,R2(:),t1*t2,t1*t2);
        tt=2*reshape(diagR*(S2(:)-E2(:)),t1,t2)-DTZ1+u*DTD1;
        ttt=2*diagR.*diagR+u*DTD+sparse(1:t1*t2,1:t1*t2,lambda2,t1*t2,t1*t2);
        L2=ttt\tt(:);
        L2=reshape(L2,t1,t2);
        L2=max(0,L2);

        tZ1=Z3(1:t1,:);
        tZ2=Z3(1+t1:end,:);
        DTZ1=reshape(Nabla'*[tZ1(:);tZ2(:)],t1,t2);
        tG1=D3(1:t1,:);
        tG2=D3(1+t1:end,:);
        DTD1=reshape(Nabla'*[tG1(:);tG2(:)],t1,t2);
        diagR=sparse(1:t1*t2,1:t1*t2,R3(:),t1*t2,t1*t2);
        tt=2*reshape(diagR*(S3(:)-E3(:)),t1,t2)-DTZ1+u*DTD1;
        ttt=2*diagR.*diagR+u*DTD+sparse(1:t1*t2,1:t1*t2,lambda2,t1*t2,t1*t2);
        L3=ttt\tt(:);
        L3=reshape(L3,t1,t2);
        L3=max(0,L3);

        L=cat(3,L1,L2,L3);
        R=cat(3,R1,R2,R3);

%% Computing for the Nabla(delta) L, preparing for the update of Equation(20) and (21) in the next.
        DeltaL1=Nabla*L1(:);
        tt1=DeltaL1(1:t1*t2);
        tt1=reshape(tt1,t1,t2);
        tt2=DeltaL1(1+t1*t2:end);
        tt2=reshape(tt2,t1,t2);
        DeltaL1=[tt1;tt2];

        DeltaL2=Nabla*L2(:);
        tt1=DeltaL2(1:t1*t2);
        tt1=reshape(tt1,t1,t2);
        tt2=DeltaL2(1+t1*t2:end);
        tt2=reshape(tt2,t1,t2);
        DeltaL2=[tt1;tt2];

        DeltaL3=Nabla*L3(:);
        tt1=DeltaL3(1:t1*t2);
        tt1=reshape(tt1,t1,t2);
        tt2=DeltaL3(1+t1*t2:end);
        tt2=reshape(tt2,t1,t2);
        DeltaL3=[tt1;tt2];

%% Shrinkage operator of the Equation (20) in the paper.
        TT=DeltaL1+Z1/u;
        D1=sign(TT).*max(abs(TT)-beta/u,0);

        TT=DeltaL2+Z2/u;
        D2=sign(TT).*max(abs(TT)-beta/u,0);

        TT=DeltaL3+Z3/u;
        D3=sign(TT).*max(abs(TT)-beta/u,0);

%% Equation(18) described in the paper. 
%% Very very important! If we comment out this iteration on E1,E2,E3, then no noise term is penalized;
%% The image is very noisy, like other methods,without denoising effect. Alterative choice is to set delta very big(100), This
%% has the same effect with this commenting.
        E1=(S1-R1.*L1)./(1+delta);
        E2=(S2-R2.*L2)./(1+delta);
        E3=(S3-R3.*L3)./(1+delta);
        E=cat(3,E1,E2,E3);

%% Equation(21) in the paper: updating Z.
        Z1=Z1+u*(DeltaL1-D1);
        Z2=Z2+u*(DeltaL2-D2);
        Z3=Z3+u*(DeltaL3-D3);
        u=u*ro;
%% Compute the residuals.
        diff_R=sum(sum(sum((R-R_pre).^2)))/sum(sum(sum((R_pre).^2)));
        diff_L=sum(sum(sum((L-L_pre).^2)))/sum(sum(sum((L_pre).^2)));
        R_pre=R;
        L_pre=L;
        disp(['diff_R: ',num2str(diff_R),char(9),char(9),'diff_L: ',num2str(diff_L)]);
        if diff_R<para.epsilon_stop_R&&diff_L<para.epsilon_stop_L
            break;
        end

end