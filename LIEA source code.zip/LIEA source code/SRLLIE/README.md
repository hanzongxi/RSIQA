# Low-light-image-enhancement

A demo for our paper: Structure-Revealing Low-Light Image Enhancement via Robust Retinex Model, TIP, 2018

As described in the paper, unlike exsiting works using FFT, we use matrix inversion to solve sub-problems. So our unoptimized demo is relatively computational resource consuming. Large input images may cause out-of-memory problem.
