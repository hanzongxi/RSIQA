%clear;
%img = double(imread('N9_2.jpg'));
img=double(imread('ss.jpg'));  % For the ss_img, we have fine_tuned the epsilon to 20/255 to achieve the best denoising result.
para.epsilon_stop_L = 1e-3;
para.epsilon_stop_R = 1e-3;
para.epsilon = 10/255;
para.u = 1;
para.ro = 1.5;
para.lambda = 5;
para.beta = 0.01;   %% beta越大，contrast越大,尤其是暗部越暗
para.omega = 0.01;
para.delta = 10;  % In the TIP paper, this delta value can be taken as 0.1, 1 or 10, we can choose it more aggressively.
                  % In this default settings, the denoising is mainly
                  % determined by the thresholding.
gamma = 2.2;

[R, L, N] = lowlight_enhancement111(img, para);

res = R.*L.^(1/gamma);
% 

% The following statement can reproduce the noise map in Fig.3.
% figure,imshow(mat2gray(N));  

figure,imshow(res)



















