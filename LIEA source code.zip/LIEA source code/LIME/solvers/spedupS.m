function S = spedupS(I, lambda, sigma, strategy)
    I = im2double(I);
    x = I;
    %% Different from tsmooth, it only uses one iteration to get the refined illuminance map.
    %% Thus, the sigma is changed as 0.15 as opposed to the 0.01 used in tsmooth.m.
    [wx, wy] = computeTextureWeights(x, sigma, strategy);
    x = solveLinearEquation(I, wx, wy, lambda);
    S = x;
end

function [retx, rety] = computeTextureWeights(fin, sigma, mode)
    vareps_s = 0.02;
    vareps = 0.001;
    fx = diff(fin, 1, 2);
    fx = padarray(fx, [0, 1], 'post');
    fy = diff(fin, 1, 1);
    fy = padarray(fy, [1, 0], 'post');
    %% This direct computing of total variation is slightly different with the 
    %% sqrt or diagonal version of total variation used in tsmooth.m.
    wtox = max(abs(fx), vareps_s).^(- 1);
    wtoy = max(abs(fy), vareps_s).^(- 1);

    if mode == 3
        fbin = conv2_sep(fin, sigma); %% Using conv2_sep instead of the lpfilter
        gfx = diff(fbin, 1, 2);
        gfx = padarray(gfx, [0, 1], 'post');
        gfy = diff(fbin, 1, 1);
        gfy = padarray(gfy, [1, 0], 'post');
        wtbx = max(abs(gfx), vareps).^(- 1);
        wtby = max(abs(gfy), vareps).^(- 1);
        retx = wtbx .* wtox;
        rety = wtby .* wtoy;
    elseif mode == 2
        retx = wtox .* wtox;  %% When mode==2 or mode==3, 
        rety = wtoy .* wtoy;
    elseif mode == 1
        retx = wtox;
        rety = wtoy;
    end

    retx(:, end) = 0;
    rety(end, :) = 0;
end
%% LIME deletes the lpfilter function used in tsmooth.m, because it only needs to deal with 2-Dimensional image
%% instead of 3D RGB image.
function ret = conv2_sep(im, sigma)
    ksize = bitor(round(5 * sigma), 1);
    g = fspecial('gaussian', [1, ksize], sigma);
    ret = conv2(im, g, 'same');
    ret = conv2(ret, g', 'same');
end

function OUT = solveLinearEquation(IN, wx, wy, lambda)
    [r, c] = size(IN);
    k = r * c;
    dx =- lambda * wx(:);
    dy =- lambda * wy(:);
    B(:, 1) = dx;
    B(:, 2) = dy;
    d = [- r, - 1];
    A = spdiags(B, d, k, k);
    e = dx;
    w = padarray(dx, r, 'pre'); w = w(1:end - r);
    s = dy;
    n = padarray(dy, 1, 'pre'); n = n(1:end - 1);
    D = 1 - (e + w + s + n);
    A = A + A' + spdiags(D, 0, k, k);
    L = ichol(A, struct('michol', 'on'));
    [tout, ~] = pcg(A, IN(:), 0.1, max(min(lambda * 100, 40), 10), L, L');
    OUT = reshape(tout, r, c);
end
