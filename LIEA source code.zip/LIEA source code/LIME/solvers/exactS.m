function [T, obj] = exactS(I, alpha, sigma, strategy)
    d{1} = [- 1, 1];
    d{2} = [- 1; 1];
    T = zeros(size(I));
    Z{1} = T; Z{2} = T;
    DS = 0;

    for k = 1:2
        D{k} = psf2otf(d{k}, size(I));
        DS = DS + abs(D{k}).^2;
        dt{k} = real(ifftn(D{k} .* fftn(T)));
    end

    mu = 1;
    rho = 1.2;
    maxIter = 60;
    tol = 1e-5;
    converged = false;

    [W{1}, W{2}] = computeTextureWeights(I, sigma, strategy);

    iter = 0;

    while ~converged
        iter = iter + 1;
        DU = 0;

        for k = 1:2
            u{k} = max(abs(dt{k} + Z{k} / mu) - alpha * W{k} / mu, 0) .* sign(dt{k} + Z{k} / mu);
            DU = DU + mu * (conj(D{k}) .* fftn(u{k} - Z{k} / mu));
        end

        T = real(ifftn((fftn(2 * I) + (DU)) ./ (2 + mu * DS)));

        for k = 1:2
            dt{k} = real(ifftn(D{k} .* fftn(T)));
            Z{k} = Z{k} + mu * (dt{k} - u{k});
        end

        mu = mu * rho;

        if iter > maxIter
            converged = true;
        end

        obj(iter) = norm([u{1}(:) - dt{1}(:); u{2}(:) - dt{2}(:)]) / norm(I(:));

        if obj(iter) < tol
            converged = true;
        end

    end

end

function [retx, rety] = computeTextureWeights(fin, sigma, mode)

    if mode == 1
        retx = ones(size(fin));
        rety = retx;
        return
    end

    d{1} = [- 1, 1];
    d{2} = [- 1; 1];
    D{1} = psf2otf(d{1}, size(fin));
    D{2} = psf2otf(d{2}, size(fin));
    vareps = 0.001;

    if mode == 2
        fbin = fin;
    else
        fbin = conv2_sep(fin, sigma);
    end

    gfx = real(ifftn(D{1} .* fftn(fbin)));
    gfy = real(ifftn(D{2} .* fftn(fbin)));
    wtbx = max(abs(gfx), vareps).^(- 1);
    wtby = max(abs(gfy), vareps).^(- 1);
    retx = wtbx;
    rety = wtby;
end

function ret = conv2_sep(im, sigma)
    ksize = bitor(round(5 * sigma), 1);
    g = fspecial('gaussian', [1, ksize], sigma);

    ret = conv2(im, g, 'same');
    ret = conv2(ret, g', 'same');

end
