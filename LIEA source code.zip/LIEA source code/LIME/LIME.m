function [I, t_b, t_our] = LIME(L, para)

    if max(L(:)) > 1
        L = im2double(L);
    end

    lambda = para. lambda;
    sigma = para. sigma;
    gamma = para. gamma;
    solver = para. solver;
    strategy = para. strategy;
    t_b = max(L, [], 3);

    if solver == 1
        t_out = spedupS(imresize(t_b, 0.5), lambda, sigma, strategy);
    else
        t_out = exactS(imresize(t_b, 0.5), lambda, sigma, strategy);
    end

    t_our = imresize(t_out, size(t_b));
    t = max(abs(t_our), 0.0001).^gamma;
    I = L ./ repmat(t, [1, 1, size(L, 3)]);
    I(I > 1) = 1;
end
