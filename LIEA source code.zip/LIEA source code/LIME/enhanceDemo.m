%clc;close all;clear all;
addpath(genpath('./'));
%%
filename = '3.bmp';
L = imresize(im2double(imread(filename)),1);

%--------------------------------------------------------------
post = false; % Denoising?

para.lambda = 0.15; % Trade-off coefficient. Although this parameter can perform well in a relatively large range, 
% it should be tuned for different solvers and weighting strategies due to 
% their difference in value scale. 

% Typically, lambda for exact solver < for sped-up solver
% and using Strategy III < II < I
% ---> lambda = 0.15 is fine for SPED-UP SOLVER + STRATEGY III 
% Note by Hanzongxi, 0.01 for the 1.bmp, 0.03 for the 2.bmp, when using the exact solver.


para.sigma = 2; % Sigma for Strategy III
para.gamma = 0.7; %  Gamma Transformation on Illumination Map
para.solver = 1; % 1: Sped-up Solver; 2: Exact Solver
para.strategy = 3;% 1: Strategy I; 2: II; 3: III

%---------------------------------------------------------------
tic
[I, T_ini,T_ref] = LIME(L,para);
toc

figure(1);imshow(L);title('Input');
figure(2);imshow(I);title('LIME');
% figure(3);imshow(T_ini,[]);colormap hot;title('Initial T');
% figure(4);imshow(T_ref,[]);colormap hot;title('Refined T');
%% Post Processing
if post
YUV = rgb2ycbcr(I);
Y = YUV(:,:,1);

sigma_BM3D = 10;
[~, Y_d] = BM3D(Y,Y,sigma_BM3D,'lc',0);

I_d = ycbcr2rgb(cat(3,Y_d,YUV(:,:,2:3)));
I_f = (I).*repmat(T_ref,[1,1,3])+I_d.*repmat(1-T_ref,[1,1,3]);

figure(5);imshow(I_d);title('Denoised ');
figure(6);imshow(I_f);title('Recomposed');
end
