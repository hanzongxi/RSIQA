function mappic=BLT(pic)

    list=0:255;
    tag=list<=127;
    fsmall=17*(1-sqrt(list/127))+3;
    flarge=3/128*(list-127)+3;
    jnd=fsmall.*tag+flarge.*(~tag);
    mlist=0:255;

    mlist(1)=127;
    for i=2:256
        previous=round(mlist(i-1));
        if previous>256
            break;
        end

        mlist(i)=mlist(i-1)+jnd(previous)/jnd(i)*0.63; % It is a JND-based tone mapping curve. Aim is to preserve local contrast and detail.
    end                                                % Its function is like the gamma-boosted curve.
                                                       % The parameter 0.63 is specially tuned to cover the whole range of [127 256], 
                                                       % 也就是从[1 256]通过JND正比例映射到full的[127 256],比例系数刚好是0.63        
    mlist(i:end)=mlist(i-1);  % This statement is easy to understand, when breaking 256, the following mlist are set to 256.
    mappic=mlist(round(pic));
end