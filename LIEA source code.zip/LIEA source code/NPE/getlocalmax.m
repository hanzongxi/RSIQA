function output=getlocalmax(pic,win)
    [m,n]=size(pic);
    extpic=getextpic(pic,win);
    output=zeros(m,n);
    for i=1+win:m+win
        for j=1+win:n+win
            modual=extpic(i-win:i+win,j-win:j+win);
            output(i-win,j-win)=max(modual(:));
        end
    end
end

%% why use getlocalmax? The ordfilt2,(or the maximum filter) has exactly the same effect without any difference.

% a=imread('1.jpg');
% b=getlocalmax(rgb2gray(a),7);
% c=ordfilt2(rgb2gray(a),15*15,ones(15,15),'symmetric');
% 
% figure,imshow(uint8(b))
% figure,imshow(c)
% 
% d=(b==c);
% sum(d(:))  % the result is 1080000


















