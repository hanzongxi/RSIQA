function output=NPEA(input)
    pic=imread(input);
    [m,n,~]=size(pic);
%% Preprocessing of the input image
    tpic=double(pic);
    tpic=tpic/max(tpic(:))*255;
    % Maximum value of three channels, R, G, B
    G=max(tpic(:,:,1),max(tpic(:,:,2),tpic(:,:,3)));       

%% This segment of shit is equivalent to the stretchlim built-in function in Matlab.
    % G1 = imadjust(uint8(G),stretchlim(G,[0.1,1]), stretchlim(G,[0.1,1]));
    % G1 = max(double(G1),10);
    % figure,imshow(uint8(G1))

    [count,~]=imhist(uint8(G));
    sumPoint=0;
    dl=1;
    while(sumPoint<m*n*0.1)
        sumPoint=sumPoint+count(dl);
        dl=dl+1;
    end
    dl=dl-1;
    tag=G>dl;
    G=G.*tag+(~tag).*dl;

    G=max(G,10);    
    %figure,imshow(uint8(G))  % Show the preprocessing result of G.    

%% Brightness-pass filtering result of G.     
    G=BiFltL(round(G));
    %figure,imshow(uint8(G))    % Show the brightness-pass filter result.
    tpic(:,:,1)=tpic(:,:,1)./G;
    tpic(:,:,2)=tpic(:,:,2)./G;
    tpic(:,:,3)=tpic(:,:,3)./G;     
    %figure,imshow(tpic,[])     % Show the reflectance.  

%% Show the enhanced illuminance.
    TG=BLT(G);
    %figure,imshow(uint8(TG))
    tpic(:,:,1)=tpic(:,:,1).*TG;
    tpic(:,:,2)=tpic(:,:,2).*TG;
    tpic(:,:,3)=tpic(:,:,3).*TG;
    tpic=Post(tpic);
    output=uint8(tpic);
end