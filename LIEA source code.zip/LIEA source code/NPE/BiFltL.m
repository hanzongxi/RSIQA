function out=BiFltL(img)

    [m,n]=size(img);
    win=7;
    localmin=cbright(img,win);
    %% Showing the cbright result, which is esstentially the same as 
    % figure,imshow(uint8(localmin));  
    % SE = strel("square",15);
    % cbright1=imclose(img,SE);
    % figure,imshow(uint8(cbright1))
%% I want to re-implement this segment of code by colfilt or nlfilter, but failed.
%% In colfilt, the number of columns may change; in nlfilter, the parameter cann't be passed in.
    win=20;
    extimg=getextpic(img,win);
    extmin=getextpic(localmin,win);
    
    sigmar=5;
    gn=256;
    coef=zeros(gn,gn);
    coev=zeros(gn,gn);
    for i=1:gn
        rg=i:gn;
        coef(i,rg)=exp((i-rg)/(2*sigmar^2));
        coev(i,rg)=coef(i,rg).*rg;
    end
    rimg=zeros(m,n);

    for i=win+1:win+m
        for j=win+1:win+n
            r=coef(extimg(i,j)+1,extmin(i-win:i+win,j-win:j+win)+1);
            v=coev(extimg(i,j)+1,extmin(i-win:i+win,j-win:j+win)+1);
            rimg(i-win,j-win)=sum(r(:));
            img(i-win,j-win)=sum(v(:));
        end
    end
    out=img./rimg;
end