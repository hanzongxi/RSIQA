%% Calculate the predict mos and srocc, plcc, klcc, rmse of 10 general purpose and contrast oriented metrics on nphd .

load names.mat;
load mos.mat;

% predict_mos_niqe=zeros(510,1);
% predict_mos_brisque=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names{i});
%     img=imresize(img,0.25);
%     predict_mos_niqe(i)=niqe(img);
%     predict_mos_brisque(i)=brisque(img);
% end
% 
% save predict_mos_niqe.mat predict_mos_niqe
% save predict_mos_brisque.mat predict_mos_brisque
% 
% [a b c d]=verify_performance(mos,predict_mos_niqe)  % 0.1527 0.1031 0.1810 27.4807
% [a b c d]=verify_performance(mos,predict_mos_brisque) % 0.1224 0.0810 0.3008 26.6465



%% IL_NIQE
% addpath('ILNIQE')
% 
% templateModel = load('templatemodel.mat');
% templateModel = templateModel.templateModel;
% mu_prisparam = templateModel{1};
% cov_prisparam = templateModel{2};
% meanOfSampleData = templateModel{3};
% principleVectors = templateModel{4};
% 
% predict_mos_ilniqe=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names{i});
%     img=imresize(img,0.25);
%     predict_mos_ilniqe(i) = computequality(img,mu_prisparam,cov_prisparam,principleVectors,meanOfSampleData);
% 
% end
% 
% save predict_mos_ilniqe.mat predict_mos_ilniqe
% 
% [a b c d]=verify_performance(mos,predict_mos_ilniqe)  % 0.3334 0.2298 0.3822 25.8192

%% M3
% addpath('M3')
% load('Learned_SVR_model_on_LIVE.mat','LIVE_SVR_M3');
% svr_model = LIVE_SVR_M3;
% 
% 
% predict_mos_m3=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names{i});
%     img=imresize(img,0.25);
%     imgDis  =double(rgb2gray(img));
%     feature = Grad_LOG_CP_TIP(imgDis);
%     predict_mos_m3(i) = svmpredict(zeros(1, 1), feature, svr_model);
% end
% 
% save predict_mos_m3.mat predict_mos_m3
% 
% [a b c d]=verify_performance(mos,predict_mos_m3)  % 0.1252 0.0858 0.2024 27.3617

%% SNP_NIQE
% addpath('SNP_NIQE')
%  load modelparameters.mat
% 
%  blocksizerow    = 96;
%  blocksizecol    = 96;
%  blockrowoverlap = 0;
%  blockcoloverlap = 0;
% 
% predict_mos_snpniqe=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names{i});
%     img=imresize(img,0.25);
%     img=rgb2gray(img);
%     predict_mos_snpniqe(i) = computequality(img,blocksizerow,blocksizecol,blockrowoverlap,blockcoloverlap,mu_prisparam,cov_prisparam);
% 
% end
% 
% save predict_mos_snpniqe.mat predict_mos_snpniqe
% 
% [a b c d]=verify_performance(mos,predict_mos_snpniqe)  % 0.3961 0.2767 0.4184 25.3772


%% Fang
addpath('Fang')
predict_mos_fang=zeros(510,1);

for i=1:510
    i
    img=imread(names{i});
    img=imresize(img,0.25);
    predict_mos_fang(i) = fang(img);
end

save predict_mos_fang.mat predict_mos_fang

[a b c d]=verify_performance(mos,predict_mos_fang)  % 0.6039 0.4348 0.6405 21.4575

