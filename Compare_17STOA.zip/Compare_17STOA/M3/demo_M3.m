load('Learned_SVR_model_on_LIVE.mat','LIVE_SVR_M3');
svr_model = LIVE_SVR_M3;
imgPath='/Users/hanzongxi/Desktop/NIQA/Night database/1/';
%imgPath='image/';
imgDir=dir([imgPath '*.jpg']);
num_image=length(imgDir);
feature_mat = zeros(num_image, 40);
for i = 1:num_image
    tic;
    imgDis=imread([imgPath imgDir(i).name]);
    imgDis  =double(rgb2gray(imgDis));
    feature = Grad_LOG_CP_TIP(imgDis);
    feature_mat(i,:) = feature;
    toc;
end

predict_score = svmpredict(zeros(num_image, 1), feature_mat, svr_model);
% predict_score��imag_Path������ͼ��Ԥ��������һ����������

% score=[11:-1:1]';
% realigned_score=[predict_score(3:11);predict_score(1:2)];
% corr(realigned_score,score,'type','Spearman')
% corr(realigned_score,score,'type','Kendall')




    