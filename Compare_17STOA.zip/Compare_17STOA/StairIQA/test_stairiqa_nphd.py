import os
import csv
import numpy as np

predict_score_stairiqa=[]


with open('names.csv') as f:  # the code of the read csv part is from P.175 in the Python cookbook.
	f_csv=csv.reader(f) 
	headers=next(f_csv)
	for i, row in enumerate(f_csv):

		print(i+1)  # The for loop of python starts from 0.
		dst_name=row[0];					
		print(dst_name)
		# we can change the model as you want, fr to nr, piecewise to weighted
		# command_str="python evaluate.py  --model './models/fr_live_patchwise.model'  --top 'patchwise'"+' '+dst_name+' '+ref_name
		command_str="python -u test_staircase_ensemble.py --test_image_name"+' '+dst_name+' '+"--test_method five --output_name output.txt"
		print(command_str)
		os.system(command_str)

		f = open('output.txt','r')
		result=str(f.read())
		predict_score_stairiqa.append(result)
			
	print(len(predict_score_stairiqa))	#the number of images in NPHD are 510.

with open('predict_mos_stairiqa.txt', 'w') as file:
    file.writelines(predict_score_stairiqa)                            





			
			

	        
		

