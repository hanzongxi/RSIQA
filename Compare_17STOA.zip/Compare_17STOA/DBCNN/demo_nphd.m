%% Testing code to calculate the quality of an image.
load names.mat;
load mos.mat;

predict_mos_dbcnn=zeros(510,1);
for i=1:510
    i
    img_path = names{i};  %% In line 15，16, this path is directly used to read an image.
    net_path = './data/checkgpu/live-seed-01/fine-tuned-model/net-deployed.mat';

    mode = 'cpu'; %or cpu

    dagnet = load(net_path);
    dagnet = dagnn.DagNN.loadobj(dagnet.net) ;
    move(dagnet, mode)
    dagnet.mode = 'test';
    dagnet.conserveMemory = 0;
    averageImage = reshape(dagnet.meta.meta1.normalization.averageImage,[1,1,3]);

    im = imread(img_path);
    im=imresize(im,0.25); % we resize our night image because of it is too large.

    if strcmp(mode,'gpu') == 1
        im = gpuArray(single(im));
    else im=single(im);
    end
    data = bsxfun(@minus,im,averageImage);
    inputs = {'input', data, 'netb_input', data} ;
    dagnet.eval(inputs) ;
    %predicting the objective quality score of the input image
    predict_mos_dbcnn(i) = gather(dagnet.vars(54).value);
end

save predict_mos_dbcnn.mat predict_mos_dbcnn
[a b c d]=verify_performance(mos,predict_mos_dbcnn)  % 0.5118 0.3613 0.5285 23.7200






