function [L, M, N] = rgb2lmn_lyt(img)

   imageRef = img;

    L = 0.06 * double(imageRef(:,:,1)) + 0.63 * double(imageRef(:,:,2)) + 0.27 * double(imageRef(:,:,3));
    
    M = 0.3 * double(imageRef(:,:,1)) + 0.04 * double(imageRef(:,:,2)) - 0.35 * double(imageRef(:,:,3));
    
    N = 0.34 * double(imageRef(:,:,1)) - 0.6 * double(imageRef(:,:,2)) + 0.17 * double(imageRef(:,:,3));
    

end