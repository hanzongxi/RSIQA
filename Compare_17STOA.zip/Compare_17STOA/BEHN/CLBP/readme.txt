DemoCodesOutex.m	shows the basic operations of CLBP. please download Outex Database from http://www.outex.oulu.fi first and then extract the Outex_TC_00010 database to the correct folder. 

ClassifyOnNN.m 		computes the classification accuracy
clbp.m 			generates CLBP operator
distMATChiSquare.m 	computes the dissimilarity between training samples and a test sample
ReadOutexTxt.m		gets picture IDs and class IDs from txt for Outex Database

GETMAPPING.m		downloaded from http://www.ee.oulu.fi/mvg/
