%% This code reimplements the BEHN algorithm, written by Hanzongxi. 
%% It receives an uint8 true-color night-time image as input and needs the CLBP package.

function feat = behn_feature(img)

addpath('./CLBP');
feat = [];

%% Compute the brightness feature.
% The dark channel prior map is computed based on the  Dehaze code in the Github(demo-->dehaze-->get_dark_channel)
% The L channel of LMN is computed based on the BNBT code in previous TMM paper. L and DCP are double type matrixs.
DCP_map=get_dark_channel(img,15);
[L,M,N]=rgb2lmn(img); % M and N will be used in the colorness feature.
% Compute the natural logarithm of DCP and L channel.
DCP_log=255*exp(log(0.0001+DCP_map./255));
L_log=255*exp(log(0.0001+L./255));

bright_feat1=mean2(DCP_map);
bright_feat2=mean2(L);
bright_feat3=mean2(DCP_log);
bright_feat4=mean2(L_log);
bright_feat5=skewness(DCP_map(:));
bright_feat6=skewness(L(:));
bright_feat = [bright_feat1, bright_feat2, bright_feat3, bright_feat4, bright_feat5, bright_feat6];

%% Compute the contrast feature. Convert the Color image to the Grayscale.
img1=rgb2gray(img); 
para=[1/9, 1/7, 1/5, 1/3, 1, 3, 5, 7, 9];
entropy_feat=zeros(1,9);
svd_feat=zeros(1,9);
for i=1:9
    img_inter=double(uint8(para(i)*img1));
    entropy_feat(i)=compute_2Dentropy(img_inter);

    s=svd(img_inter,"econ");
    svd_feat(i)=sum(s)/nnz(s); %nnz function counts the non-zero singular value numbers
    svd_feat(i)=svd_feat(i)/var(img_inter(:));
end
contrast_feat = [entropy_feat, svd_feat]; %18 dimensional contrast features in total. 

%% Compute the structural feature. Double typed grayscale image, which is needed in both GM and LBP feature computation.
img2=double(img1); 
sigma = 0.5;
[gx,gy] = gaussian_derivative(img2,sigma);
grad_im = sqrt(gx.^2+gy.^2);
[gx1,gy1] = gaussian_derivative(grad_im,sigma);
grad_im1 = sqrt(gx1.^2+gy1.^2);
[gx2,gy2] = gaussian_derivative(grad_im1,sigma);
grad_im2 = sqrt(gx2.^2+gy2.^2);
HGM=grad_im+grad_im1+grad_im2;
gm_feat= hist(HGM(:),10);  %Totally, 10 GM features.

%% Compute the CLBP feature.
offset=[0 -1; 1 -1; 1 0; 1 1; 0 1; -1 1; -1 0; -1 -1];
mapping=getmapping(8,'riu2'); 
[CLBP_S,CLBP_M,CLBP_C]=clbp(img2,offset,mapping,'nh');
CLBP_C=hist(CLBP_C(:),0:1);
CLBP_C=CLBP_C/sum(CLBP_C);

struct_feat=[gm_feat, CLBP_C, CLBP_S, CLBP_M];
%% Compute the color feature.
O1 = double(img(:,:,1)) - double(img(:,:,2));   
O2 = 0.5 * double(img(:,:,1)) + 0.5 * double(img(:,:,2)) - double(img(:,:,3));
var_O1=var(O1(:)); var_O2=var(O2(:));
u_O1=abs(mean(O1(:))); u_O2=abs(mean(O2(:)));
C1=log(var_O1)+log(var_O2)-0.2*log(u_O1)-0.2*log(u_O2);

var_M=var(M(:)); var_N=var(N(:));
u_M=abs(mean(M(:))); u_N=abs(mean(N(:)));
C2=log(var_M)+log(var_N)-0.2*log(u_M)-0.2*log(u_N);

img3=rgb2ycbcr(img);
C3_YCbCr=[235, 240, 240]./[mean2(img3(:,:,1)), mean2(img3(:,:,2)), mean2(img3(:,:,3))];

color_feat=[C1, C2, C3_YCbCr];
%% Concatenate all features.
feat=[bright_feat, contrast_feat, color_feat, struct_feat];

end













