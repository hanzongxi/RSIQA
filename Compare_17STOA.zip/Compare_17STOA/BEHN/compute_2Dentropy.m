function entropy = compute_2Dentropy(img)
img=double(img);
window=ones(3,3);
window(2,2)=0;
window=window/sum(window(:));
%% imfilter provides more possibilities than the filter2 funciton.
img1=imfilter(img,window,"symmetric","same"); 
%% Histogram computation
ctrs{1} = 0:255;ctrs{2} = 0:255;
N1 = hist3([img(:),img1(:)],ctrs); 
N1 = N1(:)/sum(N1(:));
entropy=-sum(N1.*log2(N1));

