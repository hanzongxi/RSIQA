%% Calculate the predict mos and srocc, plcc, klcc, rmse of 10 general purpose and contrast oriented metrics on nphd.
%% This code is for 4 metrics which can only be run on windows

load names.mat;
load mos.mat;

% PC uses the rightslash vs. Mac，so replace it
strrep_func = @(str) strrep(str, '/', '\');
names_rightslash=cellfun(strrep_func, names, 'UniformOutput', false);
               
%% BIQME
%% Copy the BIQME code into the upper, or the database folder 
% disp('Begin BIQME')
% predict_mos_biqme=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names_rightslash{i});
%     img=imresize(img,0.25);
%     predict_mos_biqme(i) = BIQME(img);
% end
% 
% save predict_mos_biqme.mat predict_mos_biqme
% 
% [a b c d]=verify_performance(mos,predict_mos_biqme)  % 0.5665 0.4007 0.6199 21.9248


%% NIQMC
% addpath('NIQMC')
% disp('Begin NIQMC')
% predict_mos_niqmc=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names_rightslash{i});
%     img=imresize(img,0.25);
%     predict_mos_niqmc(i) = NIQMC(img);
% end
% 
% save predict_mos_niqmc.mat predict_mos_niqmc
% 
% [a b c d]=verify_performance(mos,predict_mos_niqmc)  % 0.4115 0.2853 0.4909 24.3420


%% BPRI
% disp('Begin BPRI')
% addpath('BPRI')
% predict_mos_bpri=zeros(510,1);
% 
% for i=1:510
%     i
%     img=imread(names_rightslash{i});
%     img=imresize(img,0.25);
%     predict_mos_bpri(i) = BPRI(img);
% end
% 
% save predict_mos_bpri.mat predict_mos_bpri
% 
% [a b c d]=verify_performance(mos,predict_mos_bpri)  % 0.2628 0.1790 0.3330 26.3460
% 
% 
%% BMPRI
disp('Begin BMPRI')
addpath('BMPRI')
predict_mos_niqmc=zeros(510,1);

for i=1:510
    i
    img=imread(names_rightslash{i});
    img=imresize(img,0.25);
    predict_mos_bmpri(i) = BMPRI(img);
end

save predict_mos_bmpri.mat predict_mos_bmpri

[a b c d]=verify_performance(mos,predict_mos_bmpri)  % 0.1592  0.1067  0.2242  27.2290

