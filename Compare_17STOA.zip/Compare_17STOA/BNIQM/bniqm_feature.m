function feat = bniqm_feature(I)

img=double(rgb2gray(I));
img=imresize(img,0.25); % Our image is too large, scale it
feat1=mean2(img);    % Brightness
%==========================================================================
J=blkproc(img,[64 64],@mean2);
feat2=std2(J);       % Brightness homogeneous
%==========================================================================
feat3=lpc_si(img);   % Lpc_si sharpness， which uses the conference code.
%==========================================================================
feat4=estimateNoiseSDUsingKurts(img,8); % noise estimation using SINE
%==========================================================================
I_HSV=rgb2hsv(I);
feat5=mean2(I_HSV(:,:,2)); % Saturation feature
%==========================================================================
I_V = I_HSV(:,:,3);   % The HSV_V value, or the brightness layer.
I_histeq=I_HSV;
I_histeq(:,:,3) = histeq(I_V);
I_histeq = hsv2rgb(I_histeq);
feat6=NIQMC1(I,im2uint8(I_histeq)); % Contrast feature

feat7=nn_feature_center(I); % 1000-dimensional semantics feature

feat=[feat1 feat2 feat3 feat4 feat5 feat6 feat7];




function gg = NIQMC1(im1,im2)
%==========================================================================
% 1) Please cite the paper (K. Gu, W. Lin, G. Zhai, X. Yang, W. Zhang, and 
% C. W. Chen, "No-reference quality metric of contrast-distorted images
% based on information maximization," IEEE Trans. Cybernetics, 2017, in 
% press.)
% 2) If any question, please contact me through guke.doctor@gmail.com; 
% gukesjtuee@gmail.com. 
% 3) Welcome to cooperation, and I am very willing to share my experience.
%==========================================================================
% if size(im,3) == 1
% im(:,:,1:3) = repmat(im,[1,1,3]);
% end
% aa = 0.8;
% uu = 0.2:0.2:1;
% tt = 7;
%% Preprocessing
im1 = double(rgb2gray(im1));
im2 = double(rgb2gray(im2));
% im2 = bfilter(im1/255,1,[3,0.1],tt)*255;
% im3 = armodel(im1,tt);
% im4 = aa*im2+(1-aa)*im3;
% im4 = im4(1:tt:end,1:tt:end);
% sal = fes_index(im);
% sal = imresize(sal,size(im4));
% %% Local Measure
% [vv,vv] = sort(sal(:),'descend');
% for i = 1:length(uu)
% ww = uint8(im4(vv(1:round(uu(i)*end))));
% pp = hist(ww,0:4:255);
% pp = (1+256*pp)/sum(1+256*pp);
% zz(i) = -sum(pp.*log2(pp));
% end
% ff = max(zz);
%% Global Measure
qq = 0:2:255;
rr = hist(im1(:),qq);
uu = hist(im2(:),qq);
rr = (1+2*rr)/sum(1+2*rr);
uu = (1+2*uu)/sum(1+2*uu);
%uu = ones(1,numel(qq))/sum(ones(1,numel(qq)));
gg = kldiv(qq,uu,rr,'js');


%=======================================================
function KL = kldiv(varValue,pVect1,pVect2,varargin)
if ~isequal(unique(varValue),sort(varValue)),
warning('KLDIV:duplicates','X contains duplicate values. Treated as distinct values.')
end
if ~isequal(size(varValue),size(pVect1)) || ~isequal(size(varValue),size(pVect2)),
error('All inputs must have same dimension.')
end
% Check probabilities sum to 1:
if (abs(sum(pVect1) - 1) > .00001) || (abs(sum(pVect2) - 1) > .00001),
error('Probablities don''t sum to 1.')
end
if ~isempty(varargin),
switch varargin{1},
case 'js',
logQvect = log2((pVect2+pVect1)/2);
KL = .5 * (sum(pVect1.*(log2(pVect1)-logQvect)) + ...
sum(pVect2.*(log2(pVect2)-logQvect)));
case 'sym',
KL1 = sum(pVect1 .* (log2(pVect1)-log2(pVect2)));
KL2 = sum(pVect2 .* (log2(pVect2)-log2(pVect1)));
KL = (KL1+KL2)/2;
otherwise
error(['Last argument' ' "' varargin{1} '" ' 'not recognized.'])
end
else
KL = sum(pVect1 .* (log2(pVect1)-log2(pVect2)));
end