function [kurt] = kurtFunc(cleanKurt, noiseSD, index, vars)
    f = @(x) (cleanKurt-3)/((1+x)^2)+3;
    kurt = f(noiseSD^2/(vars(index)-noiseSD^2));
end