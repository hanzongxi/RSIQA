function feat = nn_feature(I)


% net = googlenet(); 
% net = inceptionv3();
% net = shufflenet();
% net = densenet201();
% net = vgg16();
% net = alexnet();
net = squeezenet();

% net = resnet18();
% layer = 'pool5-7x7_s1';
% layer = 'pool5';
% layer = 'node_200';
% layer = 'fc1000'; %resnet
% layer = 'loss3-classifier'; %googlenet
% layer = 'predictions'; %inceptionv3
layer = 'pool10'; %squeezenet

% layer = 'avg_pool';

% layer = 'node_202'; %shufflenet
% layer = 'fc1000'; %desnet201
% layer = 'fc8'; %vgg16

features = activations(net,I,layer);
features = double(features);
% feat = features(1,1,:);

feat = squeeze(features);

end
