function [noiseSD,estimatedKurt] = estimateNoiseSDUsingKurts(noiseI, patchSize)
%
% ESTIMATENOISESDUSINGKURTS - estimate noise level in an image using the
% kurtosis of marginal filter response distributions
%
% input parameters:
%
% noiseI - the noised image to be estimated
% patchSize - size of DCT patches to use (8 should work fine)
%
% output:
% 
% noiseSD - the estimated noise standard deviation
% estimatedKurt - the estimated original constant kurtosis for the image
%
% This code implements the noise estimation method described in:
% "Scale invariance and noise in natural images" by Daniel Zoran and Yair Weiss,
% ICCV 2009
%
% see http://www.cs.huji.ac.il/~yweiss for details
%
% This code is made available under the GPL license. Usage is free for non-commercial applications.
% Please include the source code of this package with any application that uses it.
% Copyright to Daniel Zoran and Yair Weiss - 2009
%

N = patchSize^2;

% create DCT basis filters
W = DCTBasis(patchSize);

% remove DC from image
noiseI = noiseI - mean2(noiseI);

% gather statistics of the image
noiseVars = zeros(1,N);
noiseKurts = zeros(1,N);

for i=2:N
    temp = conv2(noiseI,reshape(W(i,:),[patchSize patchSize]),'valid');
    noiseVars(i) = var(temp(:));
    noiseKurts(i) = kurtosis(temp(:));
end

% find which noise sd and kurtosis explain the statistics best
[noiseSD,estimatedKurt] = fitShapeAndSDUsingKurts(noiseVars,noiseKurts);
noiseSD = abs(noiseSD);
end