function im7 =BOIEM (im1)
load coff 
im2 =rgb2ycbcr (im1 ); 
im3 =im2 (:,:,1 ); 
eq =histeq (uint8 (im3 )); 
hu =hist (double (eq (:)),0 :255 ); 
hu =hu /sum (hu ); 
im4 =double (im3 ); 
hi =hist (im4 (:),0 :255 ); 
hi =hi /sum (hi ); 
im5 =coff (ceil (mean (im4 (:))/32 )+1 ,im4 +1 ); 
hs =hist (im5 (:),0 :255 ); 
hs =hs /sum (hs ); 
ho =find_optc (im2 ,hi ,hu ,hs ); 
im6 =histeq (im3 ,ho ); 
im6 (:,:,2 :3 )=im2 (:,:,2 :3 ); 
im7 =ycbcr2rgb (im6 ); 

function ho =find_optc (im1 ,hi ,hu ,hs )
xx (1 ,:)=[0.0010 ,0.9611 ]; 
xx (2 ,:)=[0.0010 ,1.0381 ]; 
xx (3 ,:)=[0.0009 ,1.1307 ]; 
for i =1 :3 
ho =(hi +xx (i ,1 )*hu +xx (i ,2 )*hs )/(1 +xx (i ,1 )+xx (i ,2 )); 
im2 =histeq (im1 (:,:,1 ),ho ); 
im1 (:,:,1 )=im2 ; 
im2 =ycbcr2rgb (im1 ); 
q (i ,:)=BIQME (im2 ); 
end
[~,i ]=max (q (:,1 )); 
ho=(hi +xx (i ,1 )*hu +xx (i ,2 )*hs )/(1 +xx (i ,1 )+xx (i ,2 )); 








