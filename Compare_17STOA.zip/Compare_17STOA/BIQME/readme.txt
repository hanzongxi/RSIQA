
1) Please cite the paper (K. Gu, D. Tao, J.-F. Qiao, and W. Lin, "Learning a no-reference quality assessment model of enhanced images with big data," IEEE Trans. Neural Netw. Learning Syst., 2018.)

2) If any question, please contact me through guke.doctor@gmail.com; gukesjtuee@gmail.com.

3) Welcome to my homepage: https://kegu.netlify.com/
Welcome to cooperation. I am very willing to share my experience.

4) Implementation: run demo.m

5) Results: run result.m


