%% This demo reproduces the BIQME quality assessment code produced by guke.
im0 = imread('im0.png');
im1 = imread('im1.png');
im2 = imread('im2.png');

score1 = BIQME(im0)
score2 = BIQME(im1)
score3 = BIQME(im2)
%im0=0.5961, im1=0.6639, im2=0.2834



