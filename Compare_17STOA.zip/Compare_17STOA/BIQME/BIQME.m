function score = BIQME(im1)

im2 = double(rgb2gray(im1));
feat = zeros(1,17);
%% Resize the image to a smaller version. For the time-consuming phase congruency computation.
f = max(1,round(min(size(im2))/256));
if f > 1
lpf = ones(f,f);
lpf = lpf/sum(lpf(:));
im3 = imfilter(im2,lpf,'symmetric','same');
im3 = im3(1:f:end,1:f:end);
else
im3 = im2;
end
pc = phasecong3(im3);
[~,ii] = sort(-pc(:));
feat(1) = entropy(uint8(im3(ii(1:round(0.4*end)))));
%%
lvl = 3;
bands = dwt_cdf97(im2,lvl);
feat(2) = ssq(bands{2});
feat(3) = ssq(bands{3});
%%
m = [3.5,5.5,7.5];
im4 = uint8(im2);
for j = 1:length(m)
feat(j+3) = entropy(im4/m(j));
feat(j+6) = entropy(im4*m(j));
end                               
%%
[CE_gray,CE_by,CE_rg] = CE(im1);
feat(10) = mean2(CE_gray);
feat(11) = mean2(CE_by);
feat(12) = mean2(CE_rg);    
%%
Irn = double(im1(:,:,1))./255;
Ign = double(im1(:,:,2))./255;
Ibn = double(im1(:,:,3))./255;
Id = min(min(Irn,Ign),Ibn);
feat(13) = mean2(Id);
%%
I_hsv = rgb2hsv(im1);
Is = I_hsv(:,:,2);   
feat(14) = mean2(Is);
%%
rg = double(im1(:,:,1))-double(im1(:,:,2));
by = 0.5*(double(im1(:,:,1))+double(im1(:,:,2)))-double(im1(:,:,3));   
rg = rg(:);
by = by(:);
feat(15) = sqrt(std(rg).^2+std(by).^2)+0.3*sqrt(mean(rg).^2+mean(by).^2);
feat(16:17) = brisque_feature(im2);
%% This is the SVM regression code only can work on PC
fid = fopen('test_ind.txt','w');
for jj = 1:size(feat,1)
fprintf(fid,'1 ');
for kk = 1:size(feat,2)
fprintf(fid,'%d:%f ',kk,feat(jj,kk));
end
fprintf(fid,'\n');
end
fclose(fid);
warning off all
delete output test_ind_scaled dump
system('svm-scale  -r range test_ind.txt >> test_ind_scaled');
system('svm-predict  -b 1  test_ind_scaled model output.txt>dump');
load output.txt;
score = output;
%=======================================================
function ss = ssq(bands)
alpha = 0.8;
lh_img = bands{1}.^2;
hl_img = bands{2}.^2;
hh_img = bands{3}.^2;
E_lh = log10(1+mean(lh_img(:)));
E_hl = log10(1+mean(hl_img(:)));
E_hh = log10(1+mean(hh_img(:)));
ss = alpha*E_hh + (1-alpha) *(E_lh + E_hl)/2;
%=======================================================
function feat = brisque_feature(imdist)
imdist = imresize(double(imdist),0.5);
window = fspecial('gaussian',7,7/6);
window = window/sum(sum(window));
mu        = filter2(window, imdist, 'same');
mu_sq     = mu.*mu;
sigma     = sqrt(abs(filter2(window, imdist.*imdist, 'same') - mu_sq));
structdis = (imdist-mu)./(sigma+1);
[alpha overallstd] = estimateggdparam(structdis(:));
feat               = [alpha overallstd^2];
%=======================================================
function [M, m, or, featType, PC, EO, T, pcSum] = phasecong3(varargin)
[im, nscale, norient, minWaveLength, mult, sigmaOnf, ...
k, cutOff, g, noiseMethod] = checkargs(varargin(:));     
epsilon         = .0001;          % Used to prevent division by zero.
[rows,cols] = size(im);
imagefft = fft2(im);              % Fourier transform of image
zero = zeros(rows,cols);
EO = cell(nscale, norient);       % Array of convolution results.  
PC = cell(norient,1);
covx2 = zero;                     % Matrices for covariance data
covy2 = zero;
covxy = zero;
EnergyV = zeros(rows,cols,3);     % Matrix for accumulating total energy
pcSum = zeros(rows,cols);                                      
if mod(cols,2)
xrange = [-(cols-1)/2:(cols-1)/2]/(cols-1);
else
xrange = [-cols/2:(cols/2-1)]/cols; 
end
if mod(rows,2)
yrange = [-(rows-1)/2:(rows-1)/2]/(rows-1);
else
yrange = [-rows/2:(rows/2-1)]/rows; 
end
[x,y] = meshgrid(xrange, yrange);
radius = sqrt(x.^2 + y.^2);       % Matrix values contain *normalised* radius from centre.
theta = atan2(-y,x);              % Matrix values contain polar angle.
radius = ifftshift(radius);       % Quadrant shift radius and theta so that filters
theta  = ifftshift(theta);        % are constructed with 0 frequency at the corners.
radius(1,1) = 1;                  % Get rid of the 0 radius value at the 0
sintheta = sin(theta);
costheta = cos(theta);
clear x; clear y; clear theta;    % save a little memory
lp = lowpassfilter([rows,cols],.45,15);   % Radius .45, 'sharpness' 15
logGabor = cell(1,nscale);
for s = 1:nscale
wavelength = minWaveLength*mult^(s-1);
fo = 1.0/wavelength;                  % Centre frequency of filter.
logGabor{s} = exp((-(log(radius/fo)).^2) / (2 * log(sigmaOnf)^2));  
logGabor{s} = logGabor{s}.*lp;        % Apply low-pass filter
logGabor{s}(1,1) = 0;                 % Set the value at the 0 frequency point of the filter
end
for o = 1:norient                    % For each orientation...
angl = (o-1)*pi/norient;           % Filter angle.
ds = sintheta * cos(angl) - costheta * sin(angl);    % Difference in sine.
dc = costheta * cos(angl) + sintheta * sin(angl);    % Difference in cosine.
dtheta = abs(atan2(ds,dc));                          % Absolute angular distance.
dtheta = min(dtheta*norient/2,pi);
spread = (cos(dtheta)+1)/2;        
sumE_ThisOrient   = zero;          % Initialize accumulator matrices.
sumO_ThisOrient   = zero;       
sumAn_ThisOrient  = zero;      
Energy            = zero;      
for s = 1:nscale,                  % For each scale...
filter = logGabor{s} .* spread;      % Multiply radial and angular
EO{s,o} = ifft2(imagefft .* filter);      
An = abs(EO{s,o});                         % Amplitude of even & odd filter response.
sumAn_ThisOrient = sumAn_ThisOrient + An;  % Sum of amplitude responses.
sumE_ThisOrient = sumE_ThisOrient + real(EO{s,o}); % Sum of even filter convolution results.
sumO_ThisOrient = sumO_ThisOrient + imag(EO{s,o}); % Sum of odd filter convolution results.
if s == 1 
if noiseMethod == -1     % Use median to estimate noise statistics
tau = median(sumAn_ThisOrient(:))/sqrt(log(4));   
elseif noiseMethod == -2 % Use mode to estimate noise statistics
tau = rayleighmode(sumAn_ThisOrient(:));
end
maxAn = An;
else
maxAn = max(maxAn,An);   
end
end                                       % ... and process the next scale
EnergyV(:,:,1) = EnergyV(:,:,1) + sumE_ThisOrient;
EnergyV(:,:,2) = EnergyV(:,:,2) + cos(angl)*sumO_ThisOrient;
EnergyV(:,:,3) = EnergyV(:,:,3) + sin(angl)*sumO_ThisOrient;
XEnergy = sqrt(sumE_ThisOrient.^2 + sumO_ThisOrient.^2) + epsilon;   
MeanE = sumE_ThisOrient ./ XEnergy; 
MeanO = sumO_ThisOrient ./ XEnergy; 
for s = 1:nscale,       
E = real(EO{s,o}); O = imag(EO{s,o});    % Extract even and odd
Energy = Energy + E.*MeanE + O.*MeanO - abs(E.*MeanO - O.*MeanE);
end
if noiseMethod >= 0     % We are using a fixed noise threshold
T = noiseMethod;    % use supplied noiseMethod value as the threshold
else
totalTau = tau * (1 - (1/mult)^nscale)/(1-(1/mult));
EstNoiseEnergyMean = totalTau*sqrt(pi/2);        % Expected mean and std
EstNoiseEnergySigma = totalTau*sqrt((4-pi)/2);   % values of noise energy
T =  EstNoiseEnergyMean + k*EstNoiseEnergySigma; % Noise threshold
end
Energy = max(Energy - T, 0);         
width = (sumAn_ThisOrient./(maxAn + epsilon) - 1) / (nscale-1);    
weight = 1.0 ./ (1 + exp( (cutOff - width)*g)); 
PC{o} = weight.*Energy./sumAn_ThisOrient;   % Phase congruency for this orientatio
pcSum = pcSum+PC{o};
covx = PC{o}*cos(angl);
covy = PC{o}*sin(angl);
covx2 = covx2 + covx.^2;
covy2 = covy2 + covy.^2;
covxy = covxy + covx.*covy;
end  % For each orientation
covx2 = covx2/(norient/2);
covy2 = covy2/(norient/2);
covxy = 4*covxy/norient;   % This gives us 2*covxy/(norient/2)
denom = sqrt(covxy.^2 + (covx2-covy2).^2)+epsilon;
M = (covy2+covx2 + denom)/2;          % Maximum moment
m = (covy2+covx2 - denom)/2;          % ... and minimum moment
or = atan2(EnergyV(:,:,3), EnergyV(:,:,2));
or(or<0) = or(or<0)+pi;       % Wrap angles -pi..0 to 0..pi
or = round(or*180/pi);        % Orientation in degrees between 0 and 180
OddV = sqrt(EnergyV(:,:,2).^2 + EnergyV(:,:,3).^2);
featType = atan2(EnergyV(:,:,1), OddV);  % Feature phase  pi/2 <-> white line,
function [im, nscale, norient, minWaveLength, mult, sigmaOnf, ...
k, cutOff, g, noiseMethod] = checkargs(arg)
nargs = length(arg);
if nargs < 1
error('No image supplied as an argument');
end    
im              = [];
nscale          = 4;     % Number of wavelet scales.    
norient         = 6;     % Number of filter orientations.
minWaveLength   = 3;     % Wavelength of smallest scale filter.    
mult            = 2.1;   % Scaling factor between successive filters.    
sigmaOnf        = 0.55;  % Ratio of the standard deviation of the
k               = 2.0;   % No of standard deviations of the noise
cutOff          = 0.5;   % The fractional measure of frequency spread
g               = 10;    % Controls the sharpness of the transition in
noiseMethod     = -1;    % Choice of noise compensation method. 
allnumeric   = 1;       % Numeric argument values in predefined order
keywordvalue = 2;       % Arguments in the form of string keyword
readstate = allnumeric; % Start in the allnumeric state
if readstate == allnumeric
for n = 1:nargs
if isa(arg{n},'char')
readstate = keywordvalue;
break;
else
if     n == 1, im            = arg{n}; 
elseif n == 2, nscale        = arg{n};              
elseif n == 3, norient       = arg{n};
elseif n == 4, minWaveLength = arg{n};
elseif n == 5, mult          = arg{n};
elseif n == 6, sigmaOnf      = arg{n};
elseif n == 7, k             = arg{n};
elseif n == 8, cutOff        = arg{n};
elseif n == 9, g             = arg{n};
elseif n == 10,noiseMethod   = arg{n};
end
end
end
end
if readstate == keywordvalue
while n < nargs
if ~isa(arg{n},'char') || ~isa(arg{n+1}, 'double')
error('There should be a parameter name - value pair');
end
if     strncmpi(arg{n},'im'      ,2), im =        arg{n+1};
elseif strncmpi(arg{n},'nscale'  ,2), nscale =    arg{n+1};
elseif strncmpi(arg{n},'norient' ,4), norient =   arg{n+1};
elseif strncmpi(arg{n},'minWaveLength',2), minWaveLength = arg{n+1};
elseif strncmpi(arg{n},'mult'    ,2), mult =      arg{n+1};
elseif strncmpi(arg{n},'sigmaOnf',2), sigmaOnf =  arg{n+1};
elseif strncmpi(arg{n},'k'       ,1), k =         arg{n+1};
elseif strncmpi(arg{n},'cutOff'  ,2), cutOff   =  arg{n+1};
elseif strncmpi(arg{n},'g'       ,1), g        =  arg{n+1};         
elseif strncmpi(arg{n},'noiseMethod' ,4), noiseMethod =  arg{n+1};                     
else   error('Unrecognised parameter name');
end
n = n+2;
if n == nargs
error('Unmatched parameter name - value pair');
end
end
end
if isempty(im)
error('No image argument supplied');
end
if ndims(im) == 3
warning('Colour image supplied: converting image to greyscale...')
im = double(rgb2gray(im));
end
if ~isa(im, 'double')
im = double(im);
end
if nscale < 1
error('nscale must be an integer >= 1');
end
if norient < 1 
error('norient must be an integer >= 1');
end    
if minWaveLength < 2
error('It makes little sense to have a wavelength < 2');
end          
if cutOff < 0 || cutOff > 1
error('Cut off value must be between 0 and 1');
end
function rmode = rayleighmode(data, nbins)
if nargin == 1
nbins = 50;  % Default number of histogram bins to use
end
mx = max(data(:));
edges = 0:mx/nbins:mx;
n = histc(data(:),edges); 
[dum,ind] = max(n); % Find maximum and index of maximum in histogram 
rmode = (edges(ind)+edges(ind+1))/2;
%=======================================================
function f = lowpassfilter(sze, cutoff, n)
if cutoff < 0 | cutoff > 0.5
error('cutoff frequency must be between 0 and 0.5');
end
if rem(n,1) ~= 0 | n < 1
error('n must be an integer >= 1');
end
if length(sze) == 1
rows = sze; cols = sze;
else
rows = sze(1); cols = sze(2);
end
if mod(cols,2)
xrange = [-(cols-1)/2:(cols-1)/2]/(cols-1);
else
xrange = [-cols/2:(cols/2-1)]/cols;	
end
if mod(rows,2)
yrange = [-(rows-1)/2:(rows-1)/2]/(rows-1);
else
yrange = [-rows/2:(rows/2-1)]/rows;	
end
[x,y] = meshgrid(xrange, yrange);
radius = sqrt(x.^2 + y.^2);        % A matrix with every pixel = radius relative to centre.
f = ifftshift( 1.0 ./ (1.0 + (radius ./ cutoff).^(2*n)) );   % The filter
%=======================================================
function bands = dwt_cdf97(X, Level)
if nargin < 2, error('Not enough input arguments.'); end
if ndims(X) > 3, error('Input must be a 2D or 3D array.'); end
if any(size(Level) ~= 1), error('Invalid transform level.'); end
N1 = size(X,1);
N2 = size(X,2);
LiftFilter = [-1.5861343420693648,-0.0529801185718856,0.8829110755411875,0.4435068520511142];
ScaleFactor = 1.1496043988602418;
S1 = LiftFilter(1);
S2 = LiftFilter(2);
S3 = LiftFilter(3);
ExtrapolateOdd = -2*[S1*S2*S3,S2*S3,S1+S3+3*S1*S2*S3]/(1+2*S2*S3);
LiftFilter = LiftFilter([1,1],:);
if Level >= 0   % Forward transform
for k = 1:Level
M1 = ceil(N1/2);
M2 = ceil(N2/2);
if N1 > 1         
RightShift = [2:M1,M1];
X0 = X(1:2:N1,1:N2,:);
if rem(N1,2)
X1 = [X(2:2:N1,1:N2,:);X0(M1-1,:,:)*ExtrapolateOdd(1)...
+ X(N1-1,1:N2,:)*ExtrapolateOdd(2)...
+ X0(M1,:,:)*ExtrapolateOdd(3)]...
+ filter(LiftFilter(:,1),1,X0(RightShift,:,:),...
X0(1,:,:)*LiftFilter(1,1),1);
else
X1 = X(2:2:N1,1:N2,:) ...
+ filter(LiftFilter(:,1),1,X0(RightShift,:,:),...
X0(1,:,:)*LiftFilter(1,1),1);
end
X0 = X0 + filter(LiftFilter(:,2),1,...
X1,X1(1,:,:)*LiftFilter(1,2),1);
X1 = X1 + filter(LiftFilter(:,3),1,...
X0(RightShift,:,:),X0(1,:,:)*LiftFilter(1,3),1);
X0 = X0 + filter(LiftFilter(:,4),1,...
X1,X1(1,:,:)*LiftFilter(1,4),1);
if rem(N1,2)
X1(M1,:,:) = [];
end
X(1:N1,1:N2,:) = [X0*ScaleFactor;X1/ScaleFactor];
end
if N2 > 1
RightShift = [2:M2,M2];
X0 = permute(X(1:N1,1:2:N2,:),[2,1,3]);
if rem(N2,2)
X1 = permute([X(1:N1,2:2:N2,:),X(1:N1,N2-2,:)*ExtrapolateOdd(1)...
+ X(1:N1,N2-1,:)*ExtrapolateOdd(2) ...
+ X(1:N1,N2,:)*ExtrapolateOdd(3)],[2,1,3])...
+ filter(LiftFilter(:,1),1,X0(RightShift,:,:),...
X0(1,:,:)*LiftFilter(1,1),1);
else
X1 = permute(X(1:N1,2:2:N2,:),[2,1,3]) ...
+ filter(LiftFilter(:,1),1,X0(RightShift,:,:),...
X0(1,:,:)*LiftFilter(1,1),1);
end
X0 = X0 + filter(LiftFilter(:,2),1,...
X1,X1(1,:,:)*LiftFilter(1,2),1);
X1 = X1 + filter(LiftFilter(:,3),1,...
X0(RightShift,:,:),X0(1,:,:)*LiftFilter(1,3),1);
X0 = X0 + filter(LiftFilter(:,4),1,...
X1,X1(1,:,:)*LiftFilter(1,4),1);
if rem(N2,2)
X1(M2,:,:) = [];
end
X(1:N1,1:N2,:) = permute([X0*ScaleFactor;X1/ScaleFactor],[2,1,3]);
end
N1 = M1;
N2 = M2;
end
[N1, N2] = size(X);   
bands = cell(Level, 1);
for lev = Level:-1:1
k = 2^lev;
if (lev == Level)
bands{lev} = cell(4, 1);
bands{lev}{4} = X(1:floor(N1/k),1:floor(N2/k)); % LL
else
bands{lev} = cell(3, 1);
end
bands{lev}{1} = X(1:floor(N1/k),floor(N2/k)+1:floor(2*N2/k)); % LH
bands{lev}{2} = X(floor(N1/k)+1:floor(2*N1/k),1:floor(N2/k)); % HL
bands{lev}{3} = X(floor(N1/k)+1:floor(2*N1/k),floor(N2/k)+1:floor(2*N2/k)); % HH
end
end
%=======================================================
function [CE_gray CE_by CE_rg] = CE(I)
sigma               = 3.25;
semisaturation      = 0.1; 
t1                  = 9.225496406318721e-004 *255; %0.2353; %
t2                  = 8.969246659629488e-004 *255; %0.2287; %
t3                  = 2.069284034165411e-004 *255; %0.0528; %
border_s            = 20;
break_off_sigma     = 3;
filtersize          = break_off_sigma*sigma;
x                   = -filtersize:1:filtersize;
Gauss               = 1/(sqrt(2 * pi) * sigma)* exp((x.^2)/(-2 * sigma * sigma) );
Gauss               = Gauss./(sum(Gauss));
Gx                  = (x.^2/sigma^4-1/sigma^2).*Gauss;  %LoG
Gx                  = Gx-sum(Gx)/size(x,2);
Gx                  = Gx/sum(0.5*x.*x.*Gx);
I                 = double(I);
R                   = I(:,:,1);
G                   = I(:,:,2);
B                   = I(:,:,3);
gray                = 0.299*R + 0.587*G + 0.114*B;
by                  = 0.5*R + 0.5*G - B  ;
rg                  = R - G;    
[row col dim]       = size(I);
CE_gray             = double(zeros(row, col));
CE_by               = double(zeros(row, col));
CE_rg               = double(zeros(row, col));
gray_temp1          = border_in(gray,border_s);  % Note by Hanzongxi, this operation (border_in) copies the image border for convolution.
Cx_gray             = conv2(gray_temp1, Gx, 'same');
Cy_gray             = conv2(gray_temp1, Gx','same');
C_gray_temp2        = sqrt(Cx_gray.^2+Cy_gray.^2);
C_gray              = border_out(C_gray_temp2,border_s);        
R_gray              = (C_gray.*max(C_gray(:)))./(C_gray+(max(C_gray(:))*semisaturation));
R_gray_temp1        = R_gray - t1;
index1              = find(R_gray_temp1 > 0.0000001);
CE_gray(index1)     = R_gray_temp1(index1);
by_temp1            = border_in(by,border_s);
Cx_by               = conv2(by_temp1, Gx, 'same');
Cy_by               = conv2(by_temp1, Gx','same');
C_by_temp2          = sqrt(Cx_by.^2+Cy_by.^2);
C_by                = border_out(C_by_temp2,border_s);        
R_by                = (C_by.*max(C_by(:)))./(C_by+(max(C_by(:))*semisaturation));
R_by_temp1          = R_by - t2;
index2              = find(R_by_temp1 > 0.0000001);
CE_by(index2)       = R_by_temp1(index2);
rg_temp1            = border_in(rg,border_s);
Cx_rg               = conv2(rg_temp1, Gx, 'same');
Cy_rg               = conv2(rg_temp1, Gx','same');
C_rg_temp2          = sqrt(Cx_rg.^2+Cy_rg.^2);
C_rg                = border_out(C_rg_temp2,border_s);    
R_rg                = (C_rg.*max(C_rg(:)))./(C_rg+(max(C_rg(:))*semisaturation));
R_rg_temp1          = R_rg - t3;
index3              = find(R_rg_temp1 > 0.0000001);
CE_rg(index3)       = R_rg_temp1(index3);
%=======================================================
function [nI]=border_in(I,ps)  % copy the image content out of the border, for convolution
if mod(ps,2)==0
uc     = ps/2;      % upperside copy 
dc     = ps/2-1;    % downside copy       
elseif mod(ps,2)==1
uc     = floor(ps/2);
dc     = uc;
end
ucb        = I(1:uc,:);
dcb        = I(end-dc:end,:);
Igtemp1    = [ucb;I;dcb];
lcb        = Igtemp1(:,1:uc);
rcb        = Igtemp1(:,end-dc:end);
nI         = [lcb Igtemp1 rcb]; 
%=======================================================
function [nI]=border_out(I,ps)   % exclude or crop the image border, restoring it to the original size.
if mod(ps,2)==0
uc             = ps/2;      % upperside copy 
dc             = ps/2-1;    % downside copy
elseif mod(ps,2)==1
uc             = floor(ps/2);
dc             = uc;
end
I(:,1:uc)          = [];
I(:,end-dc:end)    = [];
I(1:uc,:)          = [];
I(end-dc:end,:)    = []; 
nI=I;
%=======================================================
function [alpha leftstd rightstd] = estimateaggdparam(vec)
gam   = 0.2:0.001:10;
r_gam = ((gamma(2./gam)).^2)./(gamma(1./gam).*gamma(3./gam));
leftstd            = sqrt(mean((vec(vec<0)).^2));
rightstd           = sqrt(mean((vec(vec>0)).^2));
gammahat           = leftstd/rightstd;
rhat               = (mean(abs(vec)))^2/mean((vec).^2);
rhatnorm           = (rhat*(gammahat^3 +1)*(gammahat+1))/((gammahat^2 +1)^2);
[min_difference, array_position] = min((r_gam - rhatnorm).^2);
alpha              = gam(array_position);
%=======================================================
function [gamparam sigma] = estimateggdparam(vec)
gam                              = 0.2:0.001:10;
r_gam                            = (gamma(1./gam).*gamma(3./gam))./((gamma(2./gam)).^2);
sigma_sq                         = mean((vec).^2);
sigma                            = sqrt(sigma_sq);
E                                = mean(abs(vec));
rho                              = sigma_sq/E^2;
[min_difference, array_position] = min(abs(rho - r_gam));
gamparam                         = gam(array_position);  