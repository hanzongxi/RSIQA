import os
import csv
import numpy as np

# the original evaluate.py of WaDIQaM has been modified to stream its result into the output.txt
predict_score_wadiqam=[]


with open('names.csv') as f:  # the code of the read csv part is from P.175 in the Python cookbook.
	f_csv=csv.reader(f) 
	headers=next(f_csv)
	for i, row in enumerate(f_csv):

		print(i+1)  # The for loop of python starts from 0.
		dst_name=row[0];					
		print(dst_name)
		# we can change the model as you want, fr to nr, piecewise to weighted
		# command_str="python evaluate.py  --model './models/fr_live_patchwise.model'  --top 'patchwise'"+' '+dst_name+' '+ref_name
		command_str="python evaluate.py  --model './models/nr_live_weighted.model'  --top 'weighted'"+' '+dst_name
		print(command_str)
		os.system(command_str)

		f = open('output.txt','r')
		result=str(f.read())
		predict_score_wadiqam.append(result)
			
	print(len(predict_score_wadiqam))	#the number of images in NPHD are 510.

with open('predict_mos_wadiqam.txt', 'w') as file:
    file.writelines(predict_score_wadiqam)                            





			
			

	        
		

