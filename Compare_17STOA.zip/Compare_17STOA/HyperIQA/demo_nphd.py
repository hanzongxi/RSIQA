import torch
import torchvision
import models
from PIL import Image
import numpy as np
import csv

def pil_loader(path):
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')

#This function is added by Hanzongxi
def predict_score(im_path):

    #model_hyper = models.HyperNet(16, 112, 224, 112, 56, 28, 14, 7).cuda()
    model_hyper = models.HyperNet(16, 112, 224, 112, 56, 28, 14, 7)
    model_hyper.train(False)
    # load our pre-trained model on the koniq-10k dataset
    #Comment by Hanzongxi:
    #model_hyper.load_state_dict((torch.load('./pretrained/koniq_pretrained.pkl')))
    state_dict = torch.load('./pretrained/koniq_pretrained.pkl', map_location=lambda storage, loc: storage)
    state_dict = torch.load('./pretrained/koniq_pretrained.pkl', map_location='cpu')
    model_hyper.load_state_dict(state_dict)

    transforms = torchvision.transforms.Compose([
                    torchvision.transforms.Resize((512, 384)),
                    torchvision.transforms.RandomCrop(size=224), # Note by Hanzongxi, the RandomCrop will generate uncertain result, we can replace it with CenterCrop
                    torchvision.transforms.ToTensor(),
                    torchvision.transforms.Normalize(mean=(0.485, 0.456, 0.406),
                                                     std=(0.229, 0.224, 0.225))])

    # random crop 10 patches and calculate mean quality score
    pred_scores = []
    for i in range(10):
        img = pil_loader(im_path)
        img = transforms(img)
        #Comment by Hanzongxi:这里也可以看见tensor的作用，单纯的将img转化tensor类型，我感觉可以删掉，直接img=img.unsqueeze(0)
        #img = torch.tensor(img.cuda()).unsqueeze(0)
        img = img.unsqueeze(0)
        paras = model_hyper(img)  # 'paras' contains the network weights conveyed to target network
        # Building target network
        #Comment by Hanzongxi:
        #model_target = models.TargetNet(paras).cuda()
        model_target = models.TargetNet(paras)
        for param in model_target.parameters():
            param.requires_grad = False

        # Quality prediction
        pred = model_target(paras['target_in_vec'])  # 'paras['target_in_vec']' is the input to target net
        pred_scores.append(float(pred.item()))
    score = np.mean(pred_scores)
    # quality score ranges from 0-100, a higher score indicates a better quality
    print('Predicted quality score: %.2f' % score)
    return score


predict_score_hyperiqa=[]

with open('names.csv') as f:  # the code of the read csv part is from P.175 in the Python cookbook.
    f_csv=csv.reader(f) 
    headers=next(f_csv)
    for i, row in enumerate(f_csv):

        print(i+1)  # The for loop of python starts from 0.
        dst_name=row[0];                    
        print(dst_name)
        result=predict_score(dst_name)
        result=str(result)+'\n'
        predict_score_hyperiqa.append(result)
            
    print(len(predict_score_hyperiqa))   #the number of images in NPHD are 510.

with open('predict_mos_hyperiqa.txt', 'w') as file:
    file.writelines(predict_score_hyperiqa)  



