templateModel = load('templatemodel.mat');
templateModel = templateModel.templateModel;
metricArray=[];
imgPath='/Users/hanzongxi/Desktop/Algorithms/Expert rankings/Night/1/';
imgDir=dir([imgPath '*.jpg']);
for i=1:length(imgDir)
    imgDis=imread([imgPath imgDir(i).name]);
    mu_prisparam = templateModel{1};
    cov_prisparam = templateModel{2};
    meanOfSampleData = templateModel{3};
    principleVectors = templateModel{4};
    tic;
    metricValue = computequality(imgDis,mu_prisparam,cov_prisparam,principleVectors,meanOfSampleData)
    metricArray=[metricArray metricValue];
    toc;
end

    