%This function extracts bnbt feature, written by Hanzongxi. 
%This bnbt_feature receives an uint8 color image as input, because the
%color channel will be used for brightness computation,
%and the uint8 type is used because the rgb2gray operation
%is performed in the texture_feature stage, if the input is the double type
%the rgb2gray(double) would make the value all 1s.
function feat = bnbt_feature(img)

feat = [];
img=imresize(img,0.25); % Our image is too large, scale it

b_feat = brightness_feature(img);
t_feat = texture_feature(img);

ds_img = imresize(img,0.5);
d_b_feat = brightness_feature(ds_img);
d_t_feat = texture_feature(ds_img);


feat = [b_feat t_feat d_b_feat d_t_feat];

end