function feat = brigtness_feature_each_channel(img)

N = 400;
pp = [];
[LL,NumLabels] = superpixels(img,N);

MMM = max(max(LL));

for i = 1:MMM
    
    ind = find(LL == i);
    pp(i) = mean(img(ind));

end


sort_pp = sort(pp,'ascend');


len = length(sort_pp);
ww = 1:len;
weight = log2(1+(ww/len));

weight = weight/(sum(weight));

feat = sum(sort_pp.*weight);


end