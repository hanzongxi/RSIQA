%brightness

function feat = brightness_feature(img)

feat = [];

[LL, MM, NN] = rgb2lmn(img);

ll_feat = brigtness_feature_each_channel(LL);
mm_feat = brigtness_feature_each_channel(MM);
nn_feat = brigtness_feature_each_channel(NN);

feat = [ll_feat mm_feat nn_feat];

end