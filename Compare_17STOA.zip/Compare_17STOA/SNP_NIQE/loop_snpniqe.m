load modelparameters.mat
 blocksizerow    = 96;
 blocksizecol    = 96;
 blockrowoverlap = 0;
 blockcoloverlap = 0;
metricArray=[];
imgPath='/Users/hanzongxi/Desktop/Algorithms/Expert rankings/Night/1/';
imgDir=dir([imgPath '*.jpg']);
for i=1:length(imgDir)
    imgDis=imread([imgPath imgDir(i).name]);
    imgDis=rgb2gray(imgDis);
    tic;
    metricValue=computequality(imgDis,blocksizerow,blocksizecol,blockrowoverlap,blockcoloverlap,mu_prisparam,cov_prisparam)
    metricArray=[metricArray metricValue];
    toc;
end

    