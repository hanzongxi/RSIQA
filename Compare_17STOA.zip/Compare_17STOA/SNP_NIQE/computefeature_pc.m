function feat = computefeature_pc(error)

% Input  - MSCn coefficients
% Output - Compute the 18 dimensional feature vector 

feat          = [];
if (any(error(:)) == 0)
    error = error + 0.00001;
end
% error = abs(error)+0.0000001;
phat1 = wblfit(error(:));

% [alpha betal betar]      = estimateaggdparam(error(:));

feat                     = [feat;phat1'];