
1) Please cite the paper (K. Gu, W. Lin, G. Zhai, X. Yang, W. Zhang, and C. W. Chen, "No-reference quality metric of contrast-distorted images based on information maximization," IEEE Trans. Cybern., vol. 47, no. 12, pp. 4559-4565, Dec. 2017.)

2) If any question, please contact me through guke.doctor@gmail.com; gukesjtuee@gmail.com.

3) Welcome to my homepage: https://kegu.netlify.com/
Welcome to cooperation. I am very willing to share my experience.

4) Implementation: run demo.m

5) Results: run result.m


