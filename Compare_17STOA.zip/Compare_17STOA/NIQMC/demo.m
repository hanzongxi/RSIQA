im1 = imread('im1.png');
im2 = imread('im2.png');
img001 = imread('img001.png');
img004 = imread('img004.png');
img005 = imread('img005.png');
img029 = imread('img029.png');
NIQMC(im1)   %4.7880
NIQMC(im2)   %2.7252
NIQMC(img001)%4.5294
NIQMC(img004)%2.5745
NIQMC(img005)%3.8158
NIQMC(img029)%4.7326

