function ss = NIQMC(im)
%==========================================================================
% 1) Please cite the paper (K. Gu, W. Lin, G. Zhai, X. Yang, W. Zhang, and 
% C. W. Chen, "No-reference quality metric of contrast-distorted images
% based on information maximization," IEEE Trans. Cybernetics, 2017, in 
% press.)
% 2) If any question, please contact me through guke.doctor@gmail.com; 
% gukesjtuee@gmail.com. 
% 3) Welcome to cooperation, and I am very willing to share my experience.
%==========================================================================
if size(im,3) == 1
im(:,:,1:3) = repmat(im,[1,1,3]);
end
 aa = 0.8;        % aa is the weight for AR model and bilateral filter model.
 uu = 0.2:0.2:1;  % uu is for saliency sorting and max operation.
 tt = 7;          % tt is the neighborhood of pixels.
%% Preprocessing
im1 = double(rgb2gray(im));
im2 = bfilter(im1/255,1,[3,0.1],tt)*255;  % bilateral filtered images
im3 = armodel(im1,tt);                    % AR_reconstructed image
im4 = aa*im2+(1-aa)*im3;                  % semi_parametric model, 0.8 is the weight of bilateral filtered image.
im4 = im4(1:tt:end,1:tt:end);             % tt is for AR model, 1, 8, 15, Guke also mentioned this issue in his paper
sal = fes_index(im);                      % fes_index is the Guke saliency FES paper.
sal = imresize(sal,size(im4));
%% Local Measure
[~,vv] = sort(sal(:),'descend');
for i = 1:length(uu)
ww = uint8(im4(vv(1:round(uu(i)*end))));  % the end symbol is for the vv vector; we can directly index the im4 by the column vector of vv.
pp = hist(ww,0:4:255);
pp = (1+256*pp)/sum(1+256*pp);
zz(i) = -sum(pp.*log2(pp));
end
ff = max(zz);
%% Global Measure
qq = 0:2:255;
rr = hist(im1(:),qq);
rr = (1+2*rr)/sum(1+2*rr);
uu = ones(1,numel(qq))/sum(ones(1,numel(qq)));
%uu = (1+2*uu)/sum(1+2*uu);
gg = kldiv(qq,uu,rr,'js');
%% Overall Score
%ss = (ff-2.2*gg)/(1-2.2);
ss = (ff-2.2*gg);
%=======================================================

function B = bfilter(A,w,sigma,tt)
% Verify bilateral filter standard deviations.
sigma_d = sigma(1);
sigma_r = sigma(2);
% Apply either grayscale or color bilateral filtering.
[X,Y] = meshgrid(-w:w,-w:w);
G = exp(-(X.^2+Y.^2)/(2*sigma_d^2));
% Apply bilateral filter.
dim = size(A);
B = zeros(dim);
for i = 1:tt:dim(1)
for j = 1:tt:dim(2)
% Extract local region.
iMin = max(i-w,1);
iMax = min(i+w,dim(1));
jMin = max(j-w,1);
jMax = min(j+w,dim(2));
I = A(iMin:iMax,jMin:jMax);
% Compute Gaussian intensity weights.
H = exp(-(I-A(i,j)).^2/(2*sigma_r^2));
% Calculate bilateral filter response.
F = H.*G((iMin:iMax)-i+w+1,(jMin:jMax)-j+w+1);
B(i,j) = sum(F(:).*I(:))/sum(F(:));
end
end


%=======================================================
function imgrec = armodel(imgin,tt)
sr=3;%search range
mr=1;%model range
imgt=padarray(imgin,[sr+mr sr+mr],'symmetric');
imgrec=zeros(size(imgin));
[m n]=size(imgt);
N=(2*sr+1)^2-1;
K=(2*mr+1)^2-1;
A=zeros(N,K+1);
for ii=mr+sr+1:tt:m-sr-mr
for jj=mr+sr+1:tt:n-sr-mr
con=1;
patch0=imgt(ii-mr:ii+mr,jj-mr:jj+mr);
for iii=-sr:+sr
for jjj=-sr:+sr
if iii==0&&jjj==0
continue;
end
patch=imgt(ii+iii-mr:ii+iii+mr,jj+jjj-mr:jj+jjj+mr);
vec=patch(:);
A(con,:)=vec';
con=con+1;
end
end
b=A(:,mr*(2*mr+2)+1);
A2=A;
A2(:,mr*(2*mr+2)+1)=[];
if rcond(A2'*A2)<1e-7
a = ones(K,1)/K;
else
a = A2\b;
end
vec0=patch0(:);
vec0(mr*(2*mr+2)+1)=[];
rec=vec0'*a;
imgrec(ii-sr-mr,jj-sr-mr)=rec;
end
end
%=======================================================


function im3 = fes_index(im1)
sr = 2;
mr = 1;
len = 3;
par = 2;
gll = 5;
gss = 10;
aaa = 47;
bbb = 255;
www = 3;
sr2 = 2;
mr2 = 0.2;
ccc = 0.3;
% pre-processing
im2 = double(imresize(im1,aaa/size(im1,1),'bicubic'));
% residual estimation
ar = zeros(size(im2));
for i = 1:3
ar(:,:,i) = AR_saliency(im2(:,:,i),sr,mr);
end
bi = bfltColor(im2/255,www,sr2,mr2)*255;
ar = (ar+ccc*bi)/(1+ccc);   
% color transfer
labT = makecform('srgb2lab');
ar = double(applycform(uint8(ar),labT));
im2 = double(applycform(uint8(im2),labT));
% saliency detection
im3 = zeros(size(im2));
for j = 1:3
ar1 = ar(:,:,j)-im2(:,:,j);
ar2 = round(padarray(ar1,[len len],'symmetric'));
ar3 = im2col(ar2,[len*2+1 len*2+1],'sliding');
ar4 = zeros(size(ar3,2),1);
for i = 1:size(ar3,2)
nn=hist(ar3(:,i),-255:255);
p=(1+bbb*nn)/sum(1+bbb*nn);
ar4(i) = -sum(p.*log2(p));
end
ar5 = reshape(ar4,[size(im2,1) size(im2,2)]);
ar6 = imfilter(ar5,fspecial('gaussian',gll,gss),'symmetric','conv');
ar6 = mat2gray(ar6).^par;
ar7 = imresize(ar6,size(im2(:,:,1)),'bicubic');
im3(:,:,j) = ar7;
end
im3 = (1.5*im3(:,:,1)+im3(:,:,2)+im3(:,:,3))/(2+1.5);
%=======================================================


function B = bfltColor(A,w,sigma_d,sigma_r)
% Convert input sRGB image to CIELab color space.
A = applycform(A,makecform('srgb2lab'));
% Pre-compute Gaussian domain weights.
[X,Y] = meshgrid(-w:w,-w:w);
G = exp(-(X.^2+Y.^2)/(2*sigma_d^2));
% Rescale range variance (using maximum luminance).
sigma_r = 100*sigma_r;
% Apply bilateral filter.
dim = size(A);
B = zeros(dim);
for i = 1:dim(1)
for j = 1:dim(2)
% Extract local region.
iMin = max(i-w,1);
iMax = min(i+w,dim(1));
jMin = max(j-w,1);
jMax = min(j+w,dim(2));
I = A(iMin:iMax,jMin:jMax,:);
% Compute Gaussian range weights.
dL = I(:,:,1)-A(i,j,1);
da = I(:,:,2)-A(i,j,2);
db = I(:,:,3)-A(i,j,3);
H = exp(-(dL.^2+da.^2+db.^2)/(2*sigma_r^2));
% Calculate bilateral filter response.
F = H.*G((iMin:iMax)-i+w+1,(jMin:jMax)-j+w+1);
norm_F = sum(F(:));
B(i,j,1) = sum(sum(F.*I(:,:,1)))/norm_F;
B(i,j,2) = sum(sum(F.*I(:,:,2)))/norm_F;
B(i,j,3) = sum(sum(F.*I(:,:,3)))/norm_F;
end
end
B = applycform(B,makecform('lab2srgb'));
%=======================================================
function imgrec = AR_saliency(imgin,sr,mr)
imgt=padarray(imgin,[sr+mr sr+mr],'symmetric');
imgrec=zeros(size(imgin));
[m n]=size(imgt);
N=(2*sr+1)^2-1;
K=(2*mr+1)^2-1;
A=zeros(N,K+1);
for ii=mr+sr+1:m-sr-mr
for jj=mr+sr+1:n-sr-mr
con=1;
patch0=imgt(ii-mr:ii+mr,jj-mr:jj+mr);
for iii=-sr:+sr
for jjj=-sr:+sr
if iii==0&&jjj==0
continue;
end
patch=imgt(ii+iii-mr:ii+iii+mr,jj+jjj-mr:jj+jjj+mr);
vec=patch(:);
A(con,:)=vec';
con=con+1;
end
end
b=A(:,mr*(2*mr+2)+1);
A2=A;
A2(:,mr*(2*mr+2)+1)=[];
if rcond(A2'*A2)<1e-7
a = ones(K,1)/K;
else
a = A2\b;
end
vec0=patch0(:);
vec0(mr*(2*mr+2)+1)=[];
rec=vec0'*a;
imgrec(ii-sr-mr,jj-sr-mr)=rec;
end
end
%=======================================================
function KL = kldiv(varValue,pVect1,pVect2,varargin)
if ~isequal(unique(varValue),sort(varValue)),
warning('KLDIV:duplicates','X contains duplicate values. Treated as distinct values.')
end
if ~isequal(size(varValue),size(pVect1)) || ~isequal(size(varValue),size(pVect2))
error('All inputs must have same dimension.')
end
% Check probabilities sum to 1:
if (abs(sum(pVect1) - 1) > .00001) || (abs(sum(pVect2) - 1) > .00001)
error('Probablities don''t sum to 1.')
end
if ~isempty(varargin),
switch varargin{1},
case 'js',
logQvect = log2((pVect2+pVect1)/2);
KL = .5 * (sum(pVect1.*(log2(pVect1)-logQvect)) + ...
sum(pVect2.*(log2(pVect2)-logQvect)));
case 'sym',
KL1 = sum(pVect1 .* (log2(pVect1)-log2(pVect2)));
KL2 = sum(pVect2 .* (log2(pVect2)-log2(pVect1)));
KL = (KL1+KL2)/2;
otherwise
error(['Last argument' ' "' varargin{1} '" ' 'not recognized.'])
end
else
KL = sum(pVect1 .* (log2(pVect1)-log2(pVect2)));
end