imgPath='./night_image/';
imgDir=dir([imgPath '*.jpg']);
score=zeros(11,1);
for i=1:length(imgDir)
    i
    imgDis=imread([imgPath imgDir(i).name]);
    imgDis=imresize(imgDis,0.25);
    score(i)=NIQMC(imgDis);
end
score=[score(3:11);score(1:2)];

 
%% 
%score=[5.27 4.76 5.01 5.10 4.83 5.19 5.21 5.17 4.88 4.38 4.47];
corr(score,[1:11]','type','Spearman')  % -0.4364. 
corr(score,[1:11]','type','Kendall')   % -0.2727

%% The result is also very reasonable, like Fangyuming's method